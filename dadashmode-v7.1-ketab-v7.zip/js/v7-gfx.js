/* DADASHMODE v7 · program renderer + «BEAST» animation / SFX library
   - Draws the whole V7 show (every state of the director book V7) on the same 1920×1080 stage canvas, on top of the v5 renderer.
   - V7FX: MrBeast-grade broadcast animations (punch-in numbers, money burst, stamps, glitch, versus, panic timer, vault…) + synthesized SFX.
   - 100% procedural (Canvas2D + WebAudio): works offline, no downloaded assets, no licence issues.
   - Additive: v5 scenes, v5 FX and v5 animations are untouched; V7 only paints when the V7 engine is ON (or when a gallery preview runs). */
(function(){
'use strict';
const D=window.DM5;
const C={bg:'#070b24',bg2:'#10205e',y:'#ffd60a',gold:'#f5b82e',red:'#ff2e4d',grn:'#19e27a',blu:'#2f7bff',cy:'#27e0ff',pur:'#a06bff',ink:'#fbf7ee',dim:'#a3abd0',blk:'#05071a',org:'#ff8a1f'};
const fa=n=>String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]).replace(/\./g,'٫');
const cl=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const eo=x=>1-Math.pow(1-cl(x),4);
const ex=x=>{x=cl(x);return x>=1?1:1-Math.pow(2,-10*x)};
const punch=x=>{x=cl(x);const c1=1.3,c3=c1+1;return 1+c3*Math.pow(x-1,3)+c1*Math.pow(x-1,2)};/* broadcast "punch-in": short overshoot */
const now=()=>performance.now()/1000;
const DF=s=>`${s}px Lalezar, Vazirmatn, sans-serif`;
const UF=(s,w=800)=>`${w} ${s}px Vazirmatn, Tahoma, sans-serif`;
const hexA=(h,a)=>{h=String(h).replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');const n=parseInt(h,16);return `rgba(${n>>16&255},${n>>8&255},${n&255},${a})`};
const mixC=(a,b,t)=>{const p=x=>{x=x.replace('#','');const n=parseInt(x,16);return [n>>16&255,n>>8&255,n&255]};const A=p(a),B=p(b);return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,'0')).join('')};
const rnd=i=>{const x=Math.sin(i*127.1+311.7)*43758.5453;return x-Math.floor(x)};
const G2=()=>g;/* stage ctx (stage.js global) */

/* ---------------- settings ---------------- */
const LS='v7-gfx';const SET=Object.assign({program:true,theme:'beast',shake:true,particles:true,safe:false,key:false,hudScale:1,sfx:1},(()=>{try{return JSON.parse(localStorage.getItem(LS)||'{}')}catch(e){return {}}})());
const saveSet=()=>{try{localStorage.setItem(LS,JSON.stringify(SET))}catch(e){}};

/* ---------------- primitives ---------------- */
function rr(x,y,w,h,r){const c=G2();c.beginPath();r=Math.min(r,h/2,w/2);c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath()}
function fitSize(str,maxW,size,font=DF){const c=G2();c.font=font(size);const w=c.measureText(str).width;return w>maxW?Math.max(10,Math.floor(size*maxW/w)):size}
/* MrBeast-style display text: heavy stroke, hard drop shadow, optional glow */
function T(str,x,y,size,o={}){const c=G2();str=String(str);c.save();c.globalAlpha*=o.alpha??1;c.translate(x,y);if(o.rot)c.rotate(o.rot);if(o.scale!=null)c.scale(o.scale,o.scale);
 const font=o.font||DF;if(o.max)size=fitSize(str,o.max,size,font);c.font=font(size);c.textAlign=o.align||'center';c.textBaseline='middle';c.direction='rtl';c.lineJoin='round';c.miterLimit=2;
 const sh=o.shadow??size*.075;if(sh){c.fillStyle=o.shadowCol||'rgba(3,4,18,.92)';c.fillText(str,sh*.5,sh)}
 const sw=o.sw??.16;if(sw){c.lineWidth=size*sw;c.strokeStyle=o.stroke||C.blk;c.strokeText(str,0,0)}
 if(o.glow){c.shadowColor=o.glow;c.shadowBlur=size*.5}c.fillStyle=o.fill||C.ink;c.fillText(str,0,0);
 if(o.shine){c.shadowBlur=0;c.save();c.globalCompositeOperation='source-atop';const lg=c.createLinearGradient(-size*3,0,size*3,0);const p=((now()*.6)%1.6)-.3;lg.addColorStop(cl(p-.08),'rgba(255,255,255,0)');lg.addColorStop(cl(p),'rgba(255,255,255,.75)');lg.addColorStop(cl(p+.08),'rgba(255,255,255,0)');c.fillStyle=lg;c.fillText(str,0,0);c.restore()}
 c.restore()}
function U(str,x,y,size,col=C.ink,align='center',w=800,alpha=1){const c=G2();c.save();c.globalAlpha*=alpha;c.font=UF(size,w);c.fillStyle=col;c.textAlign=align;c.textBaseline='middle';c.direction='rtl';c.fillText(String(str),x,y);c.restore()}
function wrapLines(str,maxW,font){const c=G2();c.font=font;const out=[];let cur='';for(const w of String(str).split(/\s+/)){const t=cur?cur+' '+w:w;if(c.measureText(t).width>maxW&&cur){out.push(cur);cur=w}else cur=t}if(cur)out.push(cur);return out}
function pill(str,x,y,size,bg,fg=C.blk,alpha=1){const c=G2();c.save();c.globalAlpha*=alpha;c.font=UF(size,900);c.direction='rtl';const w=c.measureText(str).width+size*1.5,h=size*1.9;rr(x-w/2,y-h/2,w,h,h/2);c.fillStyle=bg;c.fill();c.fillStyle=fg;c.textAlign='center';c.textBaseline='middle';c.fillText(str,x,y+size*.05);c.restore();return w}
function slab(x,y,w,h,r,fill,stroke,lw=4){const c=G2();rr(x,y,w,h,r);c.fillStyle=fill;c.fill();if(stroke){c.lineWidth=lw;c.strokeStyle=stroke;c.stroke()}}
function ring(x,y,r,p,col,lw=14,bg='rgba(255,255,255,.1)'){const c=G2();c.save();c.lineCap='round';c.lineWidth=lw;c.strokeStyle=bg;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.stroke();c.strokeStyle=col;c.beginPath();c.arc(x,y,r,-Math.PI/2,-Math.PI/2+Math.PI*2*cl(p));c.stroke();c.restore()}
const rects=[];const hud=(x,y,w,h)=>rects.push({x,y,w,h});

/* ---------------- particles ---------------- */
const PS=[];
function burst(x,y,n,o={}){if(!SET.particles)n=Math.ceil(n/4);const cols=o.cols||[C.y,C.gold,C.ink,C.cy,C.red];for(let i=0;i<n;i++){const a=(o.dir??-Math.PI/2)+(Math.random()-.5)*(o.spread??Math.PI*2);const sp=(o.sp||900)*(.35+Math.random()*.9);
 PS.push({x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,g:o.g??1500,life:o.life||(1.4+Math.random()*1.4),t:0,col:cols[i%cols.length],s:(o.size||14)*(.5+Math.random()),rot:Math.random()*6,vr:(Math.random()-.5)*14,shape:o.shape||(i%5===0?'coin':i%3===0?'spark':'rect'),drag:o.drag??.985})}}
function rain(n,shape='bill'){for(let i=0;i<n;i++)PS.push({x:Math.random()*1920,y:-60-Math.random()*900,vx:(Math.random()-.5)*80,vy:200+Math.random()*260,g:60,life:6,t:0,col:shape==='bill'?'#3ccf6a':C.gold,s:26+Math.random()*16,rot:Math.random()*6,vr:(Math.random()-.5)*4,shape,drag:1,flut:Math.random()*6})}
function drawParticles(dt){const c=G2();for(let i=PS.length-1;i>=0;i--){const p=PS[i];p.t+=dt;if(p.t>p.life||p.y>1200){PS.splice(i,1);continue}p.vx*=p.drag;p.vy=p.vy*p.drag+p.g*dt;p.x+=p.vx*dt+(p.flut?Math.sin(p.t*3+p.flut)*40*dt:0);p.y+=p.vy*dt;p.rot+=p.vr*dt;
 const a=cl((p.life-p.t)/.5);c.save();c.globalAlpha=a;c.translate(p.x,p.y);c.rotate(p.rot);
 if(p.shape==='coin'){c.scale(Math.cos(p.t*9),1);c.beginPath();c.arc(0,0,p.s*.7,0,7);c.fillStyle=C.gold;c.fill();c.lineWidth=3;c.strokeStyle='#9a6a00';c.stroke();c.fillStyle='#fff3b0';c.fillRect(-p.s*.12,-p.s*.4,p.s*.24,p.s*.8)}
 else if(p.shape==='bill'){c.scale(1,Math.cos(p.t*4+p.flut));c.fillStyle=p.col;c.fillRect(-p.s,-p.s*.5,p.s*2,p.s);c.strokeStyle='#0f5d2a';c.lineWidth=2;c.strokeRect(-p.s*.8,-p.s*.35,p.s*1.6,p.s*.7);c.beginPath();c.arc(0,0,p.s*.25,0,7);c.stroke()}
 else if(p.shape==='spark'){c.globalCompositeOperation='lighter';c.fillStyle=p.col;c.beginPath();c.moveTo(0,-p.s);c.lineTo(p.s*.22,0);c.lineTo(0,p.s);c.lineTo(-p.s*.22,0);c.closePath();c.fill()}
 else if(p.shape==='shard'){c.fillStyle=p.col;c.beginPath();c.moveTo(0,-p.s);c.lineTo(p.s*.7,p.s*.6);c.lineTo(-p.s*.5,p.s*.4);c.closePath();c.fill()}
 else{c.scale(1,Math.cos(p.t*7+i));c.fillStyle=p.col;c.fillRect(-p.s*.5,-p.s*.3,p.s,p.s*.6)}c.restore()}}

/* ---------------- screen shake / flash / zoom punch ---------------- */
const CAM={shake:0,shakeT:0,flash:0,flashCol:'#fff',zoom:0,zoomT:0};
const shake=(k=1)=>{if(!SET.shake)return;CAM.shake=Math.max(CAM.shake,18*k);CAM.shakeT=now()};
const flash=(a=.8,col='#ffffff')=>{CAM.flash=a;CAM.flashCol=col};
const zoomPunch=(k=.06)=>{CAM.zoom=k;CAM.zoomT=now()};
const gl=(type,o)=>{try{window.V7GL&&V7GL.kick(type,o||{})}catch(e){}};

/* ---------------- backgrounds (themes) ---------------- */
const THEMES={
 beast:{name:'BEAST · استودیوی مسابقه (الهام از مستر بیست)',a:C.y,b:C.blu,bg1:'#050a2a',bg2:'#1238a8',ray:'#3a7bff'},
 vault:{name:'گاوصندوق طلایی',a:C.gold,b:'#ff9d00',bg1:'#0c0703',bg2:'#4a2c05',ray:'#f5b82e'},
 neon:{name:'نئون شب',a:C.cy,b:C.pur,bg1:'#07021a',bg2:'#2a0a5e',ray:'#9b5cff'},
 arena:{name:'آرنای قرمز',a:C.red,b:C.y,bg1:'#140206',bg2:'#5a0a1a',ray:'#ff2e4d'}};
function bg(t,themeId){const c=G2(),th=THEMES[themeId]||THEMES.beast;
 const rg=c.createRadialGradient(960,470,60,960,540,1300);rg.addColorStop(0,th.bg2);rg.addColorStop(1,th.bg1);c.fillStyle=rg;c.fillRect(0,0,1920,1080);
 /* sunburst slices (game-show signature) */
 c.save();c.translate(960,500);c.rotate(t*.05);c.globalCompositeOperation='lighter';for(let i=0;i<24;i++){c.rotate(Math.PI*2/24);if(i%2)continue;const lg=c.createLinearGradient(0,0,0,-1400);lg.addColorStop(0,hexA(th.ray,.16));lg.addColorStop(1,hexA(th.ray,0));c.fillStyle=lg;c.beginPath();c.moveTo(0,0);c.lineTo(-190,-1400);c.lineTo(190,-1400);c.closePath();c.fill()}c.restore();
 /* moving truss lights */
 c.save();c.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const x=160+i*320,a=Math.sin(t*.7+i*1.7)*.35;c.save();c.translate(x,-20);c.rotate(a);const lg=c.createLinearGradient(0,0,0,1100);lg.addColorStop(0,hexA(i%2?th.a:th.b,.22));lg.addColorStop(1,hexA(th.a,0));c.fillStyle=lg;c.beginPath();c.moveTo(-10,0);c.lineTo(10,0);c.lineTo(120,1100);c.lineTo(-120,1100);c.closePath();c.fill();c.restore()}c.restore();
 /* LED floor */
 c.save();c.globalAlpha=.55;c.strokeStyle=hexA(th.a,.18);c.lineWidth=2;for(let i=-14;i<=14;i++){c.beginPath();c.moveTo(960+i*36,790);c.lineTo(960+i*230,1080);c.stroke()}for(let k=0;k<8;k++){const y=790+Math.pow((k+(t*.6)%1)/8,1.9)*290;c.beginPath();c.moveTo(0,y);c.lineTo(1920,y);c.stroke()}c.restore();
 /* bokeh */
 c.save();c.globalCompositeOperation='lighter';for(let i=0;i<40;i++){const x=rnd(i)*1920,y=(rnd(i+9)*1080-t*(10+rnd(i+3)*30))%1080;const yy=y<0?y+1080:y;c.fillStyle=hexA(i%3?th.a:th.b,.05+rnd(i+5)*.08);c.beginPath();c.arc(x,yy,6+rnd(i+1)*26,0,7);c.fill()}c.restore();
 const vg=c.createRadialGradient(960,540,500,960,540,1150);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(2,2,10,.7)');c.fillStyle=vg;c.fillRect(0,0,1920,1080)}

/* ---------------- icons drawn in code ---------------- */
function cup(x,y,s,col,alpha=1){const c=G2();c.save();c.globalAlpha*=alpha;c.translate(x,y);c.beginPath();c.moveTo(-s*.42,-s*.5);c.lineTo(s*.42,-s*.5);c.lineTo(s*.32,s*.5);c.lineTo(-s*.32,s*.5);c.closePath();const lg=c.createLinearGradient(-s*.4,0,s*.4,0);lg.addColorStop(0,mixC(col,'#000000',.35));lg.addColorStop(.45,mixC(col,'#ffffff',.25));lg.addColorStop(1,mixC(col,'#000000',.45));c.fillStyle=lg;c.fill();c.lineWidth=3;c.strokeStyle=mixC(col,'#000000',.6);c.stroke();c.fillStyle=hexA('#ffffff',.5);c.fillRect(-s*.45,-s*.56,s*.9,s*.1);c.restore()}
function bucket(x,y,s){const c=G2();c.save();c.translate(x,y);c.beginPath();c.moveTo(-s*.5,-s*.45);c.lineTo(s*.5,-s*.45);c.lineTo(s*.38,s*.5);c.lineTo(-s*.38,s*.5);c.closePath();const lg=c.createLinearGradient(-s*.5,0,s*.5,0);lg.addColorStop(0,'#9aa7c0');lg.addColorStop(.5,'#eef2ff');lg.addColorStop(1,'#6b7892');c.fillStyle=lg;c.fill();c.lineWidth=4;c.strokeStyle='#2a3348';c.stroke();c.beginPath();c.ellipse(0,-s*.45,s*.5,s*.12,0,0,7);c.fillStyle='#1b2236';c.fill();c.stroke();c.restore()}
function ball(x,y,r){const c=G2();c.save();const rg=c.createRadialGradient(x-r*.35,y-r*.35,r*.1,x,y,r);rg.addColorStop(0,'#ffd9a8');rg.addColorStop(.5,C.org);rg.addColorStop(1,'#8a3a00');c.fillStyle=rg;c.beginPath();c.arc(x,y,r,0,7);c.fill();c.strokeStyle='#4a1d00';c.lineWidth=r*.1;c.beginPath();c.moveTo(x-r,y);c.lineTo(x+r,y);c.moveTo(x,y-r);c.quadraticCurveTo(x+r*.6,y,x,y+r);c.stroke();c.restore()}
function lockIcon(x,y,s,col=C.gold,open=0){const c=G2();c.save();c.translate(x,y);c.lineWidth=s*.14;c.strokeStyle=col;c.beginPath();c.arc(0,-s*.18-open*s*.25,s*.3,Math.PI,0);c.lineTo(s*.3,-s*.05-open*s*.25);c.stroke();slab(-s*.45,-s*.1,s*.9,s*.7,s*.12,col);c.fillStyle=C.blk;c.beginPath();c.arc(0,s*.2,s*.09,0,7);c.fill();c.fillRect(-s*.035,s*.2,s*.07,s*.18);c.restore()}
function crown(x,y,s,col=C.gold){const c=G2();c.save();c.translate(x,y);c.beginPath();c.moveTo(-s*.5,s*.3);c.lineTo(-s*.5,-s*.2);c.lineTo(-s*.25,s*.05);c.lineTo(0,-s*.35);c.lineTo(s*.25,s*.05);c.lineTo(s*.5,-s*.2);c.lineTo(s*.5,s*.3);c.closePath();c.fillStyle=col;c.fill();c.lineWidth=s*.06;c.strokeStyle=C.blk;c.stroke();c.restore()}
function vaultDoor(x,y,r,open,t){const c=G2();c.save();c.translate(x,y);slab(-r*1.15,-r*1.15,r*2.3,r*2.3,r*.18,'#1a1f33','#5a6385',8);c.save();c.scale(1-open*.85,1);const rg=c.createRadialGradient(-r*.3,-r*.3,r*.1,0,0,r);rg.addColorStop(0,'#e9edf7');rg.addColorStop(.6,'#8b93ab');rg.addColorStop(1,'#3b4258');c.fillStyle=rg;c.beginPath();c.arc(0,0,r,0,7);c.fill();c.lineWidth=10;c.strokeStyle='#262b3d';c.stroke();
 c.rotate(t*.8*(1-open));for(let i=0;i<3;i++){c.rotate(Math.PI*2/3);c.fillStyle='#2b3147';c.fillRect(-8,0,16,r*.62);c.beginPath();c.arc(0,r*.66,18,0,7);c.fill()}c.beginPath();c.arc(0,0,r*.2,0,7);c.fillStyle=C.gold;c.fill();c.restore();
 if(open>0){c.globalCompositeOperation='lighter';const g2=c.createRadialGradient(0,0,0,0,0,r*1.4);g2.addColorStop(0,hexA(C.gold,.9*open));g2.addColorStop(1,hexA(C.gold,0));c.fillStyle=g2;c.beginPath();c.arc(0,0,r*1.4,0,7);c.fill()}c.restore()}
function briefcase(x,y,s,open,col=C.gold){const c=G2();c.save();c.translate(x,y);slab(-s*.18,-s*.62,s*.36,s*.16,s*.05,'#2a1c05');const lg=c.createLinearGradient(0,-s*.5,0,s*.5);lg.addColorStop(0,mixC(col,'#ffffff',.3));lg.addColorStop(1,mixC(col,'#000000',.4));
 c.save();c.translate(0,-s*.1);c.rotate(-open*.9);slab(-s*.8,-s*.4,s*1.6,s*.4,s*.08,lg,'#3a2600',6);c.restore();slab(-s*.8,-s*.1,s*1.6,s*.6,s*.08,lg,'#3a2600',6);
 if(open>0){c.globalCompositeOperation='lighter';const g2=c.createRadialGradient(0,-s*.2,0,0,-s*.2,s*1.3);g2.addColorStop(0,hexA('#fff4c0',open));g2.addColorStop(1,hexA(C.gold,0));c.fillStyle=g2;c.fillRect(-s*1.5,-s*1.6,s*3,s*1.6)}c.restore()}

/* ---------------- HUD: bank tiles, timer, ribbon ---------------- */
const disp={E:null,M:null},bump={E:0,M:0},lastB={E:null,M:null};
function tileX(k){return k==='E'?1920-70-440:70}
function bankTiles(s){const t=now();const b=V7.banks();const lead=V7.R.leaderOf(b);const sc=SET.hudScale||1;
 ['E','M'].forEach(k=>{if(disp[k]==null)disp[k]=b[k];if(lastB[k]!=null&&lastB[k]!==b[k]){bump[k]=t;if(b[k]>lastB[k]){burst(tileX(k)+220,120,40,{cols:[C.y,C.gold,'#fff'],sp:700});V7FX.sfx.cash&&0}}lastB[k]=b[k];disp[k]+=(b[k]-disp[k])*.12;if(Math.abs(disp[k]-b[k])<.05)disp[k]=b[k];
  const x=tileX(k),y=34,w=440*sc,h=168*sc,col=V7.color(k);const bp=cl((t-bump[k])/.6);const up=b[k]>=(disp[k]-.01);const sK=1+.08*(1-eo(bp))*(bp<1?1:0);const c=G2();c.save();c.translate(x+w/2,y+h/2);c.scale(sK,sK);c.translate(-w/2,-h/2);
  slab(0,0,w,h,34,'#0b1030',col,6);c.save();rr(0,0,w,h,34);c.clip();const lg=c.createLinearGradient(0,0,0,h);lg.addColorStop(0,hexA(col,.42));lg.addColorStop(1,hexA(col,.05));c.fillStyle=lg;c.fillRect(0,0,w,h);if(bp<1){c.globalCompositeOperation='lighter';c.fillStyle=hexA(up?C.y:C.red,.5*(1-bp));c.fillRect(0,0,w,h)}c.restore();
  U(V7.plain(k),w-28,40,34,C.ink,'right',900);c.font=UF(34,900);if(lead===k)crown(w-38-c.measureText(V7.plain(k)).width-40,38,44);
  T(fa(Math.round(disp[k])),150,h*.58,112,{fill:lead===k?C.y:C.ink,glow:bp<1?hexA(C.y,.8):null});U('ثانیه',w-40,h-44,26,C.dim,'right',700);
  const e=s.effects&&s.effects[k];let ix=w-40;if(s.shop&&s.shop.res&&e){[['hint','🔍'],['gloves','🥊'],['spicy','🌶']].forEach(([f,ic])=>{if(e[f]&&!(f==='hint'&&e.hintUsed)){U(ic,ix-150,h-44,30,C.ink,'right');ix-=46}})}
  c.restore();hud(x,y,w,h)})}
function mainTimer(s){const t=V7.timer();if(!t)return;const x=960,y=128,r=86;const c=G2();const remain=t.remain,el=t.elapsed;const val=remain!=null?remain:el||0;const total=t.total||60;const panic=remain!=null&&remain<=10&&remain>0&&!t.idle;const tt=now();
 c.save();if(panic){const k=.5+.5*Math.sin(tt*10);c.shadowColor=C.red;c.shadowBlur=40*k}slab(x-r-26,y-r-26,(r+26)*2,(r+26)*2,r+26,'#0b1030',panic?C.red:hexA(C.ink,.2),5);c.restore();
 ring(x,y,r,remain!=null?remain/total:(el||0)/total,panic?C.red:remain!=null&&remain/total<.35?C.org:C.y,16);
 const str=val>=60?`${Math.floor(val/60)}:${String(Math.floor(val%60)).padStart(2,'0')}`:(val<10&&remain!=null?val.toFixed(1):String(Math.ceil(val)));T(fa(str),x,y+6,val>=60?64:84,{fill:panic?C.red:C.ink,scale:panic?1+.06*Math.sin(tt*10):1});
 U(t.label,x,y+r+52,26,C.dim,'center',800);if(s.paused)pill('مکث',x,y-r-44,24,C.org);hud(x-r-30,y-r-30,(r+30)*2,(r+30)*2+60)}
function ribbon(s){const c=G2();const st=V7.R.STATE_FA[s.state]||s.state;c.save();c.font=UF(30,900);const w=c.measureText(st).width+120;const x=960-w/2,y=1080-70-56;
 if(SET.safe){c.strokeStyle=hexA(C.cy,.35);c.setLineDash([12,10]);c.lineWidth=2;c.strokeRect(96,54,1728,972);c.strokeRect(192,108,1536,864);c.setLineDash([])}
 c.restore();return {x,y,w}}

/* ---------------- scenes ---------------- */
const SC={};let sceneT0=0,lastState='';
function title(str,sub,t){const k=punch(cl(t/.5));T(str,960,300,120,{scale:.6+.4*k,alpha:cl(t/.25),fill:C.y,shine:true,max:1500});if(sub)U(sub,960,390,36,C.ink,'center',800,cl((t-.2)/.4))}
function vsCards(t,sub){['E','M'].forEach((k,i)=>{const x=k==='E'?1380:540;const d=eo(cl((t-.1-i*.12)/.6));const c=G2();c.save();c.translate(x+(k==='E'?1:-1)*(1-d)*500,620);slab(-300,-190,600,380,40,'#0b1030',V7.color(k),8);
 T(V7.plain(k),0,-80,96,{fill:V7.color(k),max:520});T(fa(V7.bank(k)),0,60,150,{fill:C.ink});U(sub||'ثانیه در بانک',0,150,28,C.dim);c.restore()});const k=punch(cl((t-.5)/.4));T('VS',960,620,150,{scale:k,fill:C.y,rot:-.08,alpha:cl((t-.5)/.1),font:s=>`900 ${s}px Estedad, Vazirmatn`})}
SC.READY=(s,t)=>{title('بانک زمان','هر ثانیه، یک شانس. شروع: ۴۵ | ۴۵',t);vsCards(t)};
SC.END=(s,t)=>{title('پایان قسمت','قسمت بعد، تاج رو پس می‌گیرم.',t);vsCards(t,'بانک نهایی');const b=V7.badges();U(Object.entries(b).map(([n,v])=>`${n}: ${fa(v)} نشان`).join('  ·  '),960,900,30,C.gold)};
/* R1 · one-hand cup tower */
function pyramid(cx,by,layersDone,col,t,glow){const rows=[4,3,2,1];let k=0;rows.forEach((n,r)=>{for(let i=0;i<n;i++){k++;const x=cx+(i-(n-1)/2)*92,y=by-r*96;const on=k<=layersDone;cup(x,y,90,on?col:'#3a4266',on?1:.5)}});if(glow){const c=G2();c.save();c.globalCompositeOperation='lighter';const g2=c.createRadialGradient(cx,by-150,10,cx,by-150,380);g2.addColorStop(0,hexA(C.y,.45));g2.addColorStop(1,hexA(C.y,0));c.fillStyle=g2;c.fillRect(cx-400,by-560,800,600);c.restore()}}
SC.R1=(s,t)=>{const r=s.r1,cfg=V7.cfg().r1;title('برج لیوان','۱۰ لیوان · فقط یک دست · ۲ ثانیه سالم = +'+fa(cfg.win),t);
 ['E','M'].forEach(k=>{const cx=k==='E'?1380:540;const holding=r.hold[k]!=null;const win=r.winner===k;const lay=win||holding?10:r.run?Math.min(9,Math.floor(((V7.vnow()-r.t0)/1000)*.6+(k==='E'?1:0)))%10:0;
  pyramid(cx,860,lay,V7.color(k),t,win);U(V7.plain(k),cx,930,40,V7.color(k),'center',900);
  if(holding){const p=cl((V7.vnow()-r.hold[k])/1000/cfg.hold);ring(cx+250,520,62,p,C.y,14);T(fa(Math.min(cfg.hold,Math.floor(p*cfg.hold*10)/10).toFixed(1)),cx+250,526,44)}
  if(win)T('+'+fa(cfg.win),cx,480,150,{fill:C.y,glow:hexA(C.y,.7),scale:1+.04*Math.sin(now()*6)})})};
/* R2 · distance: the farther the line, the MORE seconds (2m +5 · 3m +10 · 4m +20) — fixed V7 */
function court(y,k,s,t){const lines=V7.cfg().r2.lines;const bx=260,px=m=>bx+m*300;const c=G2();const col=V7.color(k);
 slab(150,y-120,1620,240,40,hexA('#0b1030',.85),hexA(col,.5),4);bucket(bx,y+10,120);U('سطل',bx,y+100,24,C.dim);
 lines.forEach((L,i)=>{const x=px(L.m);const chosen=s.r2.locked&&s.r2.choice[k]===L.id;c.save();c.globalAlpha=chosen||!s.r2.locked?1:.35;c.fillStyle=L.col;c.fillRect(x-7,y-96,14,192);c.restore();
  T(`${fa(L.m)} متر`,x,y-70,34,{fill:C.ink,sw:.12,alpha:chosen||!s.r2.locked?1:.5});T('+'+fa(L.sec),x+(i===2?110:95),y+10,62,{fill:L.col,alpha:chosen||!s.r2.locked?1:.45});
  if(chosen){c.save();c.translate(x+40,y+62);slab(-50,-26,100,52,26,col);U(V7.plain(k).slice(0,6),0,2,24,C.blk,'center',900);c.restore()}});
 /* "farther = more" arrow */
 c.save();c.globalAlpha=.9;c.strokeStyle=C.y;c.fillStyle=C.y;c.lineWidth=6;const ay=y+86;c.beginPath();c.moveTo(px(2)-40,ay);c.lineTo(px(4)+170,ay);c.stroke();c.beginPath();c.moveTo(px(4)+190,ay);c.lineTo(px(4)+160,ay-14);c.lineTo(px(4)+160,ay+14);c.closePath();c.fill();c.restore();
 U('دورتر = ثانیهٔ بیشتر',px(3),ay+30,26,C.y,'center',900);
 const th=s.r2.throws[k]||[];for(let i=0;i<V7.cfg().r2.throws;i++){const v=th[i];const cx=1690-i*62,cy=y-60;c.beginPath();c.arc(cx,cy,24,0,7);c.fillStyle=v==null?'rgba(255,255,255,.12)':v==='hit'?C.grn:C.red;c.fill();U(v==null?'':v==='hit'?'✓':'✕',cx,cy+2,26,C.ink,'center',900)}
 U(V7.plain(k),1690-62,y+40,34,col,'center',900);if(V7.r2Turn()===k){pill('نوبت پرتاب',1628,y+86,22,C.y)}if(s.r2.scored[k])T('گل!',1628,y-2,70,{fill:C.grn,rot:-.1})
 return {px,bx}}
SC.R2=(s,t)=>{title('راند فاصله','هر چه دورتر بایستی، ثانیهٔ بیشتر · ۳ پرتاب · فقط اولین گل',t);const a=court(560,'E',s,t);court(840,'M',s,t);
 if(!s.r2.locked)U('انتخاب خط مخفی است تا «قفل» ↵',960,440,30,C.dim)};
/* R3 · sandwich duel */
SC.R3_SANDWICH=(s,t)=>{const c3=V7.cfg().r3;title('دوئل ساندویچ','آخرین لقمه = دست‌ها بالا · ۳۰ ثانیه برای قورت · کمترین زمان می‌برد',t);
 ['E','M'].forEach(k=>{const L=V7.r3Live(k);const cx=k==='E'?1380:540,cy=640;const col=V7.color(k);const c=G2();slab(cx-330,cy-200,660,420,44,'#0b1030',col,6);U(V7.plain(k),cx,cy-150,40,col,'center',900);
  const Tv=L.T||0;T(fa((Tv||0).toFixed(1)),cx,cy-30,150,{fill:L.st==='eating'?C.ink:L.st==='mouthfull'?C.y:C.grn});
  const lab={eating:'در حال خوردن',mouthfull:'دهان‌پر · قورت بده!',final:'دهان خالی ✔'}[L.st]||L.st;U(lab,cx,cy+70,32,C.ink,'center',900);
  if(L.st==='mouthfull'){const p=L.swallow/c3.swallow;slab(cx-260,cy+110,520,28,14,'rgba(255,255,255,.12)');slab(cx-260,cy+110,520*p,28,14,p<.25?C.red:C.y);U(fa(Math.ceil(L.swallow))+' ث',cx,cy+160,28,C.dim)}
  const x=s.r3[k];if(x&&x.pen)pill('جریمه +'+fa(x.pen),cx,cy+195,22,C.red,C.ink)});
 const r=s.r3.result;if(r){const k=punch(cl((now()-(r._t||(r._t=now())))/.5));const c=G2();c.save();c.translate(960,930);c.scale(k,k);slab(-560,-60,1120,120,60,C.y);U(r.note||'',0,2,36,C.blk,'center',900);c.restore()}};
/* twist */
SC.TWIST_BANKOPEN=(s,t)=>{const c=G2();const cards=V7.R.CARDS;const gl_=Math.random()<.15;T('بانک باز شد',960+(gl_?(Math.random()-.5)*30:0),330,170,{fill:C.gold,glow:hexA(C.gold,.8),shine:true});U('ثانیه‌هاتون دیگه فقط زمان نیست. پوله.',960,440,38,C.ink,'center',800,cl((t-.6)/.5));
 cards.forEach((cd,i)=>{const x=960+(i-2)*300,y=720;const d=eo(cl((t-.8-i*.12)/.5));c.save();c.translate(x,y+(1-d)*300);c.globalAlpha=d;slab(-120,-170,240,340,26,'#0b1030',cd.color==='blue'?C.blu:cd.color==='red'?C.red:C.gold,6);lockIcon(0,-10,120,hexA(C.ink,.7));U('؟',0,110,50,C.dim,'center',900);c.restore()});
 if(gl_){gl('rgb',{k:.6})}};
/* R4 glue */
function puzzle(cx,cy,col,st){const c=G2();for(let i=0;i<6;i++){const r=Math.floor(i/3),q=i%3;const x=cx+(q-1)*130,y=cy+(r-.5)*130;slab(x-60,y-60,120,120,18,st.done?col:hexA(col,.18+.12*((i+Math.floor(now()*2))%3===0)),hexA(C.ink,.3),3)}if(st.done){T('✔',cx,cy,120,{fill:C.ink})}if(st.lock>0){c.save();c.fillStyle='rgba(255,46,77,.55)';rr(cx-200,cy-140,400,280,24);c.fill();c.restore();T(fa(Math.ceil(st.lock)),cx,cy,120,{fill:C.ink});U('سر گرگ برعکسه!',cx,cy+100,28,C.ink,'center',900)}}
SC.R4_GLUE=(s,t)=>{const r=s.r4;title('دستکش، پازل، چسب','۶ تیکه · چیدن با دستکش · اولین «تمام» معتبر = +'+fa(V7.cfg().r4.reward),t);
 ['E','M'].forEach(k=>{const cx=k==='E'?1380:540;const lock=Math.max(0,((r.lock[k]||0)-Date.now())/1000);puzzle(cx,640,V7.color(k),{done:r.valid[k],lock});U(V7.plain(k),cx,440,40,V7.color(k),'center',900);
  if(r.fin[k]!=null)pill('تمام · '+fa(V7.mmss(r.fin[k])),cx,850,26,r.valid[k]?C.grn:C.y);if(r.first===k)T('+'+fa(V7.cfg().r4.reward),cx,930,90,{fill:C.y})})};
SC.GLUE_CHALLENGE=(s,t)=>{SC.R4_GLUE(s,t);const c=G2(),ch=s.r4.ch;if(!ch)return;c.save();c.fillStyle='rgba(5,7,26,.78)';c.fillRect(0,0,1920,1080);c.restore();T('چالش چسب!',960,300,140,{fill:C.red,glow:hexA(C.red,.7)});U(`${V7.plain(ch.by)} چالش داد · برد: +۱۰ و نفر اول فقط ۵ · باخت: −۵`,960,400,34);
 [['shake','تست تکان'],['frame','قاب'],['clean','تمیزی']].forEach(([id,n],i)=>{const x=960+(1-i)*380;const v=ch.checks[id];slab(x-160,520,320,220,30,'#0b1030',v==null?hexA(C.ink,.3):v?C.grn:C.red,6);U(n,x,570,34,C.ink,'center',900);T(v==null?'…':v?'✔':'✕',x,670,100,{fill:v==null?C.dim:v?C.grn:C.red})});
 if(ch.result)T({win:'چالش موفق',lose:'چالش ناموفق',unclear:'تشخیص نمیدم'}[ch.result],960,880,110,{fill:ch.result==='win'?C.grn:ch.result==='lose'?C.red:C.y,rot:-.05})};
/* reveal */
SC.REVEAL=(s,t)=>{const rv=s.reveal;const b=V7.banks();title('رونمایی بانک','سقف فاصله: ۳۰ ثانیه · فقط یک بار',t);vsCards(rv.done?t:0);
 if(rv.done&&rv.cap){const g0=rv.cap.gap;const c=G2();const w=1200;slab(360,890,w,40,20,'rgba(255,255,255,.1)');const p=cl(Math.min(g0,60)/60);slab(360,890,w*p,40,20,g0>30?C.red:C.y);c.fillStyle=C.ink;c.fillRect(360+w*.5-3,870,6,80);U('۳۰',360+w*.5,850,26,C.ink,'center',900);U('فاصله: '+fa(g0)+(rv.cap.apply?' → ۳۰ (سقف اعمال شد)':''),960,975,32,rv.cap.apply?C.y:C.ink,'center',900)}};
/* shop */
function shopCard(cd,x,y,sc,o={}){const c=G2();const col=cd.color==='blue'?C.blu:cd.color==='red'?C.red:C.gold;c.save();c.translate(x,y);c.scale(sc,sc);if(o.rot)c.rotate(o.rot);if(o.flip!=null)c.scale(Math.max(.02,Math.abs(Math.cos(o.flip*Math.PI))),1);
 const back=o.flip!=null&&o.flip<.5;slab(-130,-190,260,380,28,back?'#11173a':'#0b1030',col,7);if(back){T('?',0,0,150,{fill:col})}else{U(cd.icon,0,-90,90);U(cd.fa,0,20,40,C.ink,'center',900);U(cd.line,0,70,24,C.dim,'center',700);pill(fa(o.price??cd.price)+' ث',0,140,30,col,cd.color==='gold'?C.blk:C.ink)}
 if(o.tag){c.rotate(-.12);slab(-120,-30,240,60,14,o.tagCol||C.y);U(o.tag,0,2,30,C.blk,'center',900)}c.restore()}
SC.SHOP=(s,t)=>{const sh=s.shop;const b=sh.banksAt||V7.banks();title('فروشگاه کارت','حداکثر ۲ کارت · فقط ۱ قرمز · مالیات نفر جلو +۵ روی قرمز/طلایی · کف ۲۰',t);
 const lead=V7.R.leaderOf(b);V7.R.CARDS.forEach((cd,i)=>{const d=eo(cl((t-.3-i*.1)/.5));const x=960+(i-2)*300;shopCard(cd,x,640+(1-d)*300,d*.95,{rot:(i-2)*.03,price:cd.price,tag:lead&&cd.color!=='blue'?'+۵ برای '+V7.plain(lead):null,tagCol:C.org})});
 ['E','M'].forEach(k=>{const x=k==='E'?1500:420;const sub=sh.sub[k];pill(sub?'ثبت شد ●':V7.shopTurn()===k?'در حال انتخاب…':'منتظر',x,930,30,sub?C.grn:V7.shopTurn()===k?C.y:hexA(C.ink,.25),sub||V7.shopTurn()===k?C.blk:C.ink);U(V7.plain(k),x,985,28,V7.color(k),'center',900)})};
SC.SHOP_REVEAL=(s,t)=>{const sh=s.shop;title('رونمایی کارت‌ها','آینه ← سپر ← اجرا',t);if(!sh.res)return;
 ['E','M'].forEach(k=>{const cx=k==='E'?1380:540;const picks=sh.picks[k];U(V7.plain(k),cx,440,44,V7.color(k),'center',900);if(!picks.length){T('هیچی!',cx,660,90,{fill:C.dim});return}
  picks.forEach((id,i)=>{const cd=V7.R.card(id);const f=cl((t-.6-i*.5)/.6);const lab=(sh.res.labels||[]).find(l=>l.card===id&&l.by===k);const tag=f>=1?(lab?({BLOCKED:'خنثی شد 🛡',BOUNCED:'برگشت 🪞 → '+V7.plain(lab.target),BURNED:'سوخت',ACTIVE:cd.color==='red'?'روی '+V7.plain(lab.target):'فعال'}[lab.res]||lab.res):'مصرف شد ✔'):null;
   shopCard(cd,cx+(i-(picks.length-1)/2)*290,660,.95,{flip:f,tag,tagCol:lab&&(lab.res==='BLOCKED'||lab.res==='BURNED')?C.red:lab&&lab.res==='BOUNCED'?C.gold:C.grn})})})};
/* risk */
SC.RISK=(s,t)=>{const rk=s.risk;const b=V7.banks();title('شوت ریسک','۰ / ۱۰ / ۲۰ علنی · همه‌چیز ۳۰ فقط برای نفر ۱۵+ عقب · کف ۲۰',t);
 ['E','M'].forEach(k=>{const cx=k==='E'?1380:540;const col=V7.color(k);const first=rk.order&&rk.order[0]===k;slab(cx-330,450,660,460,44,'#0b1030',col,6);U(V7.plain(k)+(first?' · اول اعلام می‌کند':''),cx,500,34,col,'center',900);
  const locked=rk.lock[k];const st=rk.stake[k];const opts=[0,10,20,30];opts.forEach((o,i)=>{const x=cx+(i-1.5)*150,y=620;const sel=locked&&st===o;slab(x-62,y-50,124,100,22,sel?C.y:'rgba(255,255,255,.08)',sel?C.y:hexA(C.ink,.2),3);U(o===30?'همه':fa(o),x,y+2,o===30?30:44,sel?C.blk:C.ink,'center',900)});
  if(locked){lockIcon(cx,750,90,C.y)}else U('انتخاب…',cx,750,30,C.dim);const r=rk.res[k];if(r)T(r==='hit'?`+${fa(st||0)}`:`−${fa(st||0)}`,cx,850,100,{fill:r==='hit'?C.grn:C.red})})};
/* vault */
SC.VAULT_ARMED=(s,t)=>{const v=s.vault;title('گاوصندوق','۳ ایستگاه · ۳ رقم رمز · زمانِ بانک = زمانِ دویدن',t);vaultDoor(960,660,210,0,t);
 if(s.lock.set)pill('مهر رمز · '+s.lock.seal,960,930,28,C.gold);if(v.armed&&v.order){U(`اول: ${V7.plain(v.order[0])} (${fa(V7.bank(v.order[0]))} ث)   ·   دوم: ${V7.plain(v.order[1])} (${fa(V7.bank(v.order[1]))} ث)`,960,990,32,C.ink,'center',900)}};
function stations(run,cx,y){const names=['هدف کور','اتاق حافظه','معما','گاوصندوق'];const c=G2();c.save();c.strokeStyle=hexA(C.ink,.2);c.lineWidth=8;c.beginPath();c.moveTo(cx+450,y);c.lineTo(cx-450,y);c.stroke();c.strokeStyle=C.y;c.beginPath();c.moveTo(cx+450,y);c.lineTo(cx+450-900*cl((run.station-1)/3),y);c.stroke();c.restore();
 names.forEach((n,i)=>{const x=cx+450-i*300;const done=run.station>i+1||(i===3&&run.opened);const cur=run.station===i+1;c.beginPath();c.arc(x,y,cur?36:28,0,7);c.fillStyle=done?C.grn:cur?C.y:'#1a2150';c.fill();c.lineWidth=4;c.strokeStyle=C.blk;c.stroke();U(done?'✓':fa(i+1),x,y+2,cur?34:26,done||cur?C.blk:C.ink,'center',900);U(n,x,y+62,24,cur?C.y:C.dim,'center',800)})}
function codeSlots(run,cx,y){for(let i=0;i<3;i++){const x=cx+(1-i)*130;const got=run.c[i];const showing=run.show&&run.show.i===i&&Date.now()-run.show.at<V7.cfg().vault.codeShow*1000;slab(x-54,y-70,108,140,20,'#0b1030',got?C.gold:hexA(C.ink,.25),5);T(showing?fa(V7.digit(i)):got?'●':'?',x,y+4,showing?100:60,{fill:showing?C.y:got?C.gold:C.dim})}}
function memRoom(run,v,cx,y){const ph=run.s2.phase;const pat=v.pattern||[];const hint=run.s2.hintAt&&Date.now()-run.s2.hintAt<V7.cfg().vault.hintShow*1000;for(let i=0;i<8;i++){const x=cx+(3.5-i)*150;let col='#3a4266';
 if(ph==='show'||hint)col=pat[i]?C.gold:'#8a93b8';else if(ph==='input'||ph==='done')col=run.s2.input[i]?C.gold:'#8a93b8';cup(x,y,110,col,ph==='lock'?.35:1);if(ph==='lock')U('?',x,y,44,C.ink,'center',900)}
 const lab={ready:'آماده · ↵ نمایش ۵ ثانیه',show:'به خاطر بسپار!',lock:'قفل · '+fa(Math.max(0,Math.ceil(V7.cfg().vault.memLock-(Date.now()-run.s2.at)/1000)))+' ث',input:'بچین و «بررسی» ↵',done:'✔ ۸ از ۸'}[ph]||'';U(lab,cx,y+110,34,ph==='show'?C.y:C.ink,'center',900);if(run.s2.n!=null&&ph==='input')pill(`${fa(run.s2.n)} از ۸`,cx,y-110,28,C.red,C.ink)}
function runScene(s,t){const run=V7.curRun();const v=s.vault;if(!run){title('دویدن','',t);return}const col=V7.color(run.k);const c=G2();
 T(V7.plain(run.k),960,300,80,{fill:col});stations(run,960,420);codeSlots(run,960,930);
 const st=run.station;if(!run.started){T('آماده؟',960,640,160,{fill:C.y,scale:1+.03*Math.sin(now()*5)});U('↵ شروع ساعت · '+fa(run.bank0)+' ثانیه',960,760,36);return}
 if(run.done){T(run.opened?'باز شد!':'وقت تمام!',960,620,170,{fill:run.opened?C.grn:C.red,glow:hexA(run.opened?C.gold:C.red,.6)});if(run.opened)U(fa(run.left.toFixed(1))+' ثانیه باقی ماند',960,740,44,C.y,'center',900);else U(fa(run.codes)+' رقم از ۳',960,740,40,C.ink,'center',900);return}
 if(st===1){const sh=run.s1.phase==='show';if(sh){U('فقط برای دونده · ۵ ثانیه',960,540,30,C.dim);T(v.target||'',960,650,150,{fill:C.y})}else{T('نقاشی کور',960,620,120,{fill:C.ink});U('جمنای باید حدس بزند · تلاش '+fa(run.s1.tries+1),960,720,32,C.dim)}}
 else if(st===2){memRoom(run,v,960,660)}
 else if(st===3){const r=v.riddle;const e=s.effects[run.k]||{};const txt=r?V7.R.riddleText(r,e):'';const lines=wrapLines(txt,1400,UF(44,800)).slice(0,4);lines.forEach((l,i)=>U(l,960,560+i*66,44,C.ink,'center',800));if(e.spicy)pill('🌶 معمای تند',960,500,24,C.red,C.ink);if(run.s3.hint&&r)U('🔍 '+r.hint,960,560+lines.length*66+20,32,C.cy,'center',800);
  const lk=Math.max(0,(run.s3.lockUntil-Date.now())/1000);if(lk>0){T(fa(Math.ceil(lk)),960,650,160,{fill:C.red,alpha:.9})}}
 else if(st===4){vaultDoor(960,650,150,0,now());const lk=Math.max(0,(run.code.lockUntil-Date.now())/1000);if(lk>0)T('قفل '+fa(Math.ceil(lk)),960,650,110,{fill:C.red});U('رمز سه‌رقمی را وارد کن',960,830,34)}
 if(!run.runAt&&run.started&&!run.done)pill('توقف داور',960,500,28,C.org)}
SC.RUN1=runScene;SC.RUN2=runScene;
/* case */
SC.CASE=(s,t)=>{const w=s.cse.winner;const o=eo(cl((t-.8)/1));briefcase(960,660,300,o);title('کیف طلایی','',t);if(w&&t>1.4){T(V7.plain(w),960,420,130,{fill:V7.color(w),glow:hexA(C.gold,.6),scale:punch(cl((t-1.4)/.5))})}else if(!w&&t>1.4)T('مرگ ناگهانی!',960,420,110,{fill:C.red})};
SC.CASE_L1=(s,t)=>{const w=s.cse.winner;title('لایهٔ ۱ · تاج','',t);crown(960,600,300);const b=V7.badges();if(w){T(V7.plain(w),960,820,90,{fill:V7.color(w)});U('نشان ساندویچ طلایی · مجموع: '+fa(b[V7.plain(w)]||1),960,910,34,C.gold,'center',900)}};
SC.CASE_L2=(s,t)=>{title('لایهٔ ۲ · پاکت سرنوشت','۱۲ پاکت · هیچ‌کس ندیده، حتی جمنای',t);const c=G2();const o=eo(cl((t-.5)/.8));c.save();c.translate(960,660);slab(-360,-200,720,400,24,'#e9dfc8','#8a6d3b',6);c.beginPath();c.moveTo(-360,-200);c.lineTo(0,40-240*o);c.lineTo(360,-200);c.fillStyle='#d4c4a0';c.fill();c.stroke();c.restore();
 if(s.cse.envText){T(s.cse.envText,960,640,80,{fill:C.blk,sw:0,shadow:0,max:640});const e=s.cse.env&&V7.R.ENVELOPES[s.cse.env-1];if(e)U(e.desc,960,730,30,'#3a2a10','center',800)}};
SC.CASE_L3=(s,t)=>{title('لایهٔ ۳ · پاکت مجازات','بازنده ۲ جعبه از ۶ · بعد همه رو می‌شن',t);const cs=s.cse;V7.R.BITES.forEach((bt,i)=>{const r=Math.floor(i/3),q=i%3;const x=960+(1-q)*330,y=560+r*260;const pick=cs.bites.includes(bt.n);const open=pick||cs.revealAll;
 slab(x-140,y-110,280,220,26,open?(pick?C.y:'#1a2150'):'#0b1030',pick?C.y:hexA(C.ink,.3),5);if(open){U(bt.emoji,x,y-40,64);U(bt.title,x,y+40,24,pick?C.blk:C.ink,'center',900,1)}else T(fa(bt.n),x,y,100,{fill:C.gold})})};
SC.SHOP_REVEAL_=SC.SHOP_REVEAL;

/* ---------------- FX queue (engine events + gallery) ---------------- */
const FXQ=[];const push=(kind,data={})=>{FXQ.push({kind,data,t0:now()});if(FXQ.length>30)FXQ.shift()};
const FXDUR={win:2.6,goal:2.4,miss:1.4,stamp:1.4,bankopen:3.2,state:1.2,chain:1.2,code:2,vaultopen:4,timeout:2.2,penalty:1.4,reveal:1.6,cards:1.2,sealed:1.4,mouthfull:1.2,finish:1.2,armed:2,case:3,envelope:1.5,memok:1.6,memwrong:1.4,riskhit:2.2,riskmiss:2,hold:1,
 countdown:3.4,moneyrain:5,eliminated:2.4,versus:3,lowerthird:5,panic:3,lightning:1.2,podium:4,cashcounter:3,confetti:4,spotlight:3.5,glitch:1.2,zoompunch:.8,winner:4,ballthrow:2.6,shockwave:1.4,splitflap:2.6,stinger:1.4};
function sideX(k){return k==='E'?1380:k==='M'?540:960}
function onFx(kind,data){const d=data||{};switch(kind){
 case 'win':case 'riskhit':burst(sideX(d.k),520,120,{sp:1200});shake(.7);flash(.35,C.y);zoomPunch(.05);gl('shock',{x:sideX(d.k)/1920,y:520/1080,k:1});gl('bloom',{k:1});break;
 case 'goal':burst(260,560,90,{cols:[C.grn,C.y,'#fff'],sp:900});shake(.6);gl('shock',{x:260/1920,y:.52,k:.8});break;
 case 'miss':case 'memwrong':case 'riskmiss':shake(.5);gl('rgb',{k:.8});break;
 case 'bankopen':flash(.9,C.gold);shake(1);gl('glitch',{k:1.2});gl('rgb',{k:1.2});rain(60,'coin');break;
 case 'vaultopen':flash(.8,C.gold);burst(960,640,220,{sp:1500,cols:[C.gold,C.y,'#fff']});rain(80,'bill');shake(1);gl('shock',{x:.5,y:.6,k:1.4});gl('bloom',{k:1.5});break;
 case 'timeout':flash(.6,C.red);shake(1);gl('rgb',{k:1.4});break;
 case 'code':flash(.3,C.gold);gl('shock',{x:.5,y:.86,k:.5});break;
 case 'case':setTimeout(()=>{burst(960,560,240,{sp:1500});rain(60,'bill');gl('bloom',{k:1.4})},1400);break;
 case 'state':gl('glitch',{k:.4});break;
 case 'penalty':gl('rgb',{k:.5});break;
 case 'confetti':burst(0,1080,160,{dir:-Math.PI/3,spread:.7,sp:1700});burst(1920,1080,160,{dir:-Math.PI*2/3,spread:.7,sp:1700});break;
 case 'moneyrain':rain(140,'bill');rain(40,'coin');break;
 case 'winner':burst(960,540,260,{sp:1600});rain(80,'bill');flash(.5,C.y);gl('bloom',{k:1.6});break;
 case 'lightning':flash(1,'#cfe8ff');shake(1.2);gl('rgb',{k:1});break;
 case 'eliminated':shake(1);flash(.5,C.red);gl('rgb',{k:1});break;
 case 'zoompunch':zoomPunch(.1);shake(.4);break;
 case 'shockwave':gl('shock',{x:.5,y:.5,k:1.5});break;
 case 'glitch':gl('glitch',{k:1.4});gl('rgb',{k:1.2});break}
 push(kind,d)}
function drawFX(){const c=G2();const tn=now();for(let i=FXQ.length-1;i>=0;i--){const f=FXQ[i];const a=tn-f.t0;const dur=FXDUR[f.kind]||1.5;if(a>dur){FXQ.splice(i,1);continue}const d=f.data||{};const out=cl((dur-a)/.3);
 c.save();c.globalAlpha=out;switch(f.kind){
 case 'win':case 'goal':case 'riskhit':{const k=d.k||'E';const sec=d.sec!=null?d.sec:d.st;const x=sideX(k);const p=punch(cl(a/.45));if(f.kind==='goal'){const L=(V7.cfg().r2.lines.find(l=>l.id===d.line)||{m:4});const sx=260+L.m*300,y=k==='E'?560:840;const bt=cl(a/.9);ball(sx+(260-sx)*bt,y-20-Math.sin(bt*Math.PI)*260,26)}
  if(sec!=null){T('+'+fa(sec),x,540,260,{scale:p,fill:C.y,glow:hexA(C.y,.9),rot:-.06,shine:true});U('ثانیه برای '+V7.plain(k),x,700,44,C.ink,'center',900,cl((a-.3)/.3))}break}
 case 'miss':case 'riskmiss':{const x=sideX(d.k);T(f.kind==='riskmiss'?'−'+fa(d.st||0):'✕',x,560,f.kind==='riskmiss'?200:260,{scale:punch(cl(a/.35)),fill:C.red,rot:.08});break}
 case 'stamp':{const x=sideX(d.k);c.save();c.translate(x,560);c.rotate(-.18);const k=1.8-0.8*eo(cl(a/.25));c.scale(k,k);c.lineWidth=12;c.strokeStyle=d.ok?C.grn:C.red;rr(-260,-90,520,180,24);c.stroke();T(d.text||'',0,0,110,{fill:d.ok?C.grn:C.red,sw:.08,shadow:0});c.restore();break}
 case 'bankopen':{c.fillStyle=hexA(C.gold,.15*(1-a/dur));c.fillRect(0,0,1920,1080);for(let s2=0;s2<14;s2++){if(Math.random()<.4){const y=Math.random()*1080,h=10+Math.random()*60;c.drawImage(c.canvas,0,y*(c.canvas.width/1920),c.canvas.width,h*(c.canvas.width/1920),(Math.random()-.5)*80,y,1920,h)}}break}
 case 'state':{const p=cl(a/.9);const x=1920+300-p*(1920+900);c.fillStyle=C.y;c.beginPath();c.moveTo(x,0);c.lineTo(x+320,0);c.lineTo(x+40,1080);c.lineTo(x-280,1080);c.closePath();c.fill();c.fillStyle=C.blu;c.beginPath();c.moveTo(x+360,0);c.lineTo(x+480,0);c.lineTo(x+200,1080);c.lineTo(x+80,1080);c.closePath();c.fill();
  if(a>.25&&a<1.1){T(V7.R.STATE_FA[d.st]||'',960,540,130,{fill:C.ink,scale:punch(cl((a-.25)/.35)),max:1600})}break}
 case 'chain':{const x=d.k?sideX(d.k):960;lockIcon(x,560,200*punch(cl(a/.4)),C.y);break}
 case 'code':{const p=punch(cl(a/.4));c.fillStyle='rgba(5,7,26,.55)';c.fillRect(0,0,1920,1080);T(fa(d.d!=null?d.d:'?'),960,520,420,{scale:p,fill:C.gold,glow:hexA(C.gold,.9),shine:true});U('رقم '+fa((d.i||0)+1)+' رمز',960,800,48,C.ink,'center',900);break}
 case 'vaultopen':{vaultDoor(960,560,260,eo(cl(a/1.4)),tn);T('باز شد!',960,900,150,{scale:punch(cl((a-.8)/.4)),fill:C.y,alpha:cl((a-.8)/.2)});break}
 case 'timeout':{c.fillStyle=hexA(C.red,.25+.2*Math.sin(a*20));c.fillRect(0,0,1920,1080);T('وقت تمام!',960,540,220,{fill:C.ink,scale:punch(cl(a/.4))});break}
 case 'penalty':{const x=sideX(d.k);T('−'+fa(d.sec||0),x,480-a*120,140,{fill:C.red});break}
 case 'sealed':{const x=sideX(d.k);pill('ثبت شد ●',x,860,40*punch(cl(a/.3)),C.grn);break}
 case 'mouthfull':{const x=sideX(d.k);T('دهان‌پر!',x,380,90,{fill:C.y,scale:punch(cl(a/.3))});break}
 case 'finish':{const x=sideX(d.k);T('تمام!',x,380,110,{fill:C.y,scale:punch(cl(a/.3))});break}
 case 'armed':{T('مسلح شد',960,540,150,{fill:C.red,glow:hexA(C.red,.7),scale:punch(cl(a/.4))});break}
 case 'memok':{T('۸ از ۸',960,420,150,{fill:C.grn,scale:punch(cl(a/.4))});break}
 case 'memwrong':{T(fa(d.n)+' از ۸',960,420,150,{fill:C.red,scale:punch(cl(a/.4))});break}
 case 'reveal':{c.fillStyle=hexA('#fff',.25*(1-a/dur));c.fillRect(0,0,1920,1080);break}
 case 'envelope':{burst(960,640,4,{sp:300,cols:['#fff4c0']});break}
 /* ---- gallery-only BEAST animations ---- */
 case 'countdown':{const n=3-Math.floor(a/1);if(n>0){const p=a%1;T(fa(n),960,540,520,{scale:1.4-.4*eo(p/.3),fill:C.y,alpha:1-cl((p-.7)/.3),glow:hexA(C.y,.7)})}else{T('برو!',960,540,380,{fill:C.grn,scale:punch(cl((a-3)/.3))})}break}
 case 'eliminated':{c.fillStyle='rgba(20,0,5,.5)';c.fillRect(0,0,1920,1080);c.save();c.translate(960,540);c.rotate(-.15);const k=2-eo(cl(a/.25));c.scale(k,k);slab(-620,-120,1240,240,30,C.red);T('حذف شد!',0,0,170,{fill:C.ink});c.restore();break}
 case 'versus':{const p=eo(cl(a/.6));c.fillStyle=V7.color('M');c.beginPath();c.moveTo(0,0);c.lineTo(1000*p,0);c.lineTo(900*p,1080);c.lineTo(0,1080);c.fill();c.fillStyle=V7.color('E');c.beginPath();c.moveTo(1920,0);c.lineTo(1920-920*p,0);c.lineTo(1920-1020*p,1080);c.lineTo(1920,1080);c.fill();T(V7.plain('M'),480,540,140,{alpha:p});T(V7.plain('E'),1440,540,140,{alpha:p});T('VS',960,540,260,{fill:C.y,scale:punch(cl((a-.5)/.4)),font:s=>`900 ${s}px Estedad`});break}
 case 'lowerthird':{const p=eo(cl(a/.5)),q=a>dur-.6?eo(cl((dur-a)/.5)):1;const x=1920-120-900*p*q;slab(x,800,900,130,20,C.y);slab(x-20,800,24,130,6,C.blu);U(d.name||V7.plain('E'),x+860,845,52,C.blk,'right',900);U(d.role||'بازیکن · تیم قرمز',x+860,900,30,'#2a2a2a','right',700);break}
 case 'panic':{c.fillStyle=hexA(C.red,.15+.15*Math.sin(a*14));c.fillRect(0,0,1920,1080);c.lineWidth=30;c.strokeStyle=hexA(C.red,.6+.4*Math.sin(a*14));c.strokeRect(15,15,1890,1050);T(fa(Math.max(0,10-a*3).toFixed(1)),960,540,300,{fill:C.red,scale:1+.05*Math.sin(a*14)});break}
 case 'lightning':{c.strokeStyle='#e6f3ff';c.lineWidth=8;c.shadowColor='#8fd0ff';c.shadowBlur=40;c.beginPath();let x=900+Math.random()*120,y=0;c.moveTo(x,y);while(y<1080){x+=(Math.random()-.5)*160;y+=60+Math.random()*50;c.lineTo(x,y)}c.stroke();break}
 case 'podium':{const hs=[260,380,200];[['M',540],['E',960],['',1380]].forEach(([k,x],i)=>{const h=hs[i]*eo(cl((a-i*.2)/.6));slab(x-160,1000-h,320,h,12,i===1?C.gold:'#8a93b8');T(fa(i===1?1:i===0?2:3),x,1000-h+60,80,{fill:C.blk,sw:0,shadow:0});if(k)T(V7.plain(k),x,1000-h-60,70,{fill:V7.color(k)})});break}
 case 'cashcounter':{const v=Math.round(eo(cl(a/2))*(d.to||100));T(fa(v)+' ث',960,540,300,{fill:C.grn,glow:hexA(C.grn,.6)});break}
 case 'spotlight':{c.fillStyle='rgba(0,0,0,.72)';c.fillRect(0,0,1920,1080);c.globalCompositeOperation='destination-out';const x=960+Math.sin(a*2)*600*(1-cl(a/2.5));const rg=c.createRadialGradient(x,560,50,x,560,320);rg.addColorStop(0,'rgba(0,0,0,1)');rg.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=rg;c.beginPath();c.arc(x,560,330,0,7);c.fill();break}
 case 'winner':{T('برنده!',960,420,240,{fill:C.y,scale:punch(cl(a/.5)),glow:hexA(C.y,.8),shine:true});T(d.name||V7.plain(d.k||'E'),960,640,130,{fill:V7.color(d.k||'E'),alpha:cl((a-.4)/.3)});break}
 case 'ballthrow':{/* corrected distance animation: 3 throws from 2m/3m/4m, farther line = bigger reward */const lines=V7.cfg().r2.lines;slab(150,380,1620,420,40,'rgba(5,7,26,.85)');bucket(260,620,140);lines.forEach(L=>{const x=260+L.m*300;c.fillStyle=L.col;c.fillRect(x-7,440,14,300);T('+'+fa(L.sec),x,420,70,{fill:L.col});U(fa(L.m)+' متر',x,770,30)});const idx=Math.min(2,Math.floor(a/.85));const L=lines[idx];const sx=260+L.m*300;const bt=cl((a-idx*.85)/.7);ball(sx+(260-sx)*bt,600-Math.sin(bt*Math.PI)*(180+L.m*40),26);if(bt>=1)T('+'+fa(L.sec),260,470,110,{fill:L.col,scale:punch(cl((a-idx*.85-.7)/.15))});U('دورتر = ثانیهٔ بیشتر',960,860,40,C.y,'center',900);break}
 case 'splitflap':{const txt=d.text||'بانک زمان';const n=txt.length;for(let i=0;i<n;i++){const x=960+((n-1)/2-i)*90;const p=cl((a-i*.08)/.4);slab(x-40,480,80,120,10,'#11173a');U(p<1?String.fromCharCode(0x0627+Math.floor(Math.random()*20)):txt[i],x,540,70,C.y,'center',900)}break}
 case 'glitch':case 'zoompunch':case 'shockwave':case 'confetti':case 'moneyrain':break;
 case 'stinger':{const p=cl(a/1.2);[C.y,C.blu,C.red].forEach((col,i)=>{const x=-600+p*3200-i*180;c.fillStyle=col;c.beginPath();c.moveTo(x,0);c.lineTo(x+400,0);c.lineTo(x+100,1080);c.lineTo(x-300,1080);c.fill()});break}
 }c.restore()}}

/* ---------------- WebAudio SFX (all synthesized) ---------------- */
function ac(){try{AE.init&&AE.init()}catch(e){}return window.AE&&AE.ctx}
function outBus(){return (AE.sfx||AE.master||AE.ctx.destination)}
function tone(type,f0,f1,dur,gain=.3,at=0,q){const c=ac();if(!c)return;const t=c.currentTime+at;const o=c.createOscillator(),gg=c.createGain();o.type=type;o.frequency.setValueAtTime(f0,t);if(f1)o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+dur);gg.gain.setValueAtTime(0.0001,t);gg.gain.exponentialRampToValueAtTime(gain*SET.sfx,t+.01);gg.gain.exponentialRampToValueAtTime(0.0001,t+dur);let n=o;if(q){const f=c.createBiquadFilter();f.type=q.type||'lowpass';f.frequency.value=q.f||2000;f.Q.value=q.Q||1;o.connect(f);n=f}n.connect(gg);gg.connect(outBus());o.start(t);o.stop(t+dur+.05)}
let NB=null;function noise(dur,gain=.3,at=0,ftype='bandpass',f0=1200,f1=null,Q=1){const c=ac();if(!c)return;if(!NB){NB=c.createBuffer(1,c.sampleRate*2,c.sampleRate);const d=NB.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1}const t=c.currentTime+at;const s=c.createBufferSource();s.buffer=NB;s.loop=true;const f=c.createBiquadFilter();f.type=ftype;f.frequency.setValueAtTime(f0,t);if(f1)f.frequency.exponentialRampToValueAtTime(f1,t+dur);f.Q.value=Q;const gg=c.createGain();gg.gain.setValueAtTime(0.0001,t);gg.gain.exponentialRampToValueAtTime(gain*SET.sfx,t+.01);gg.gain.exponentialRampToValueAtTime(0.0001,t+dur);s.connect(f);f.connect(gg);gg.connect(outBus());s.start(t);s.stop(t+dur+.05)}
const SFX={
 none:()=>{},
 whooshBig:()=>{noise(.7,.5,0,'bandpass',300,4000,.8);tone('sine',90,40,.6,.35)},
 glitchGold:()=>{for(let i=0;i<8;i++){tone('square',200+Math.random()*1600,null,.05,.12,i*.06)}noise(.5,.3,.1,'highpass',3000);tone('sine',60,30,1.2,.5,.5);[523,659,784,1046].forEach((f,i)=>tone('triangle',f,null,.9,.14,.6+i*.05))},
 startHorn:()=>{[0,.02].forEach(d=>tone('sawtooth',220+d*300,null,.9,.18,d,{f:1800}));tone('sawtooth',330,null,.9,.12,0,{f:1600})},
 ding:()=>{tone('sine',1318,null,1.2,.35);tone('sine',2637,null,.6,.12)},
 fail:()=>{tone('sawtooth',300,120,.6,.25,0,{f:900})},
 buzz:()=>{tone('square',110,null,.55,.25,0,{f:700});tone('square',116,null,.55,.2,0,{f:700})},
 lockClank:()=>{noise(.12,.6,0,'bandpass',2500,null,3);tone('square',180,60,.2,.3);noise(.25,.3,.08,'bandpass',900,null,2)},
 goal:()=>{noise(.18,.4,0,'lowpass',600);[523,659,784].forEach((f,i)=>tone('triangle',f,null,.4,.2,.1+i*.08));tone('sine',1046,null,.8,.2,.34)},
 miss:()=>{tone('sine',400,180,.5,.25);tone('sine',300,120,.6,.18,.15)},
 beep:()=>tone('square',880,null,.15,.18),
 pop:()=>{tone('sine',600,1200,.08,.35);noise(.05,.2,0,'highpass',3000)},
 alarm:()=>{for(let i=0;i<6;i++)tone('sawtooth',i%2?660:880,null,.18,.18,i*.2,{f:2500})},
 cash:()=>{noise(.08,.4,0,'highpass',5000);[1568,2093,2637].forEach((f,i)=>tone('sine',f,null,.5,.18,.05+i*.06));tone('triangle',784,null,.3,.2,0)},
 riser:()=>{noise(2,.35,0,'bandpass',200,6000,2);tone('sawtooth',80,800,2,.1,0,{f:2000})},
 click:()=>{noise(.03,.5,0,'highpass',4000)},
 glassCrack:()=>{noise(.4,.5,0,'highpass',3000);for(let i=0;i<6;i++)tone('sine',2000+Math.random()*3000,null,.12,.1,i*.03)},
 vaultArm:()=>{tone('sine',55,55,1.5,.5);noise(.3,.4,0,'bandpass',500,null,4);[0,.25,.5].forEach(d=>noise(.08,.5,d+.2,'bandpass',2200,null,6))},
 codeReveal:()=>{tone('sine',60,30,.8,.5);noise(.2,.4,0,'lowpass',800);tone('triangle',1760,null,.6,.2,.05)},
 scratch:()=>noise(.35,.4,0,'bandpass',1500,400,3),
 cascade:()=>{for(let i=0;i<8;i++)tone('triangle',1046*Math.pow(1.122,i),null,.25,.12,i*.06)},
 lockPulse:()=>{tone('sine',70,50,.4,.45);noise(.1,.3,0,'bandpass',1800,null,5)},
 shimmer:()=>{for(let i=0;i<10;i++)tone('sine',2000+i*300,null,.4,.06,i*.03)},
 vaultOpen:()=>{tone('sine',50,30,2,.6);noise(1.5,.35,0,'lowpass',200,2000);[523,659,784,1046,1318].forEach((f,i)=>tone('triangle',f,null,1.4,.14,.8+i*.08))},
 vaultClose:()=>{noise(.4,.6,0,'lowpass',400);tone('sine',60,30,.9,.6);tone('sawtooth',200,80,1,.12,.2,{f:800})},
 caseOpen:()=>{SFX.riser();setTimeout(()=>{noise(.3,.4,0,'lowpass',800);[392,523,659,784].forEach((f,i)=>tone('sawtooth',f,null,1.6,.08,i*.02,{f:3000}))},1400)},
 sadTrombone:()=>{[392,370,349,294].forEach((f,i)=>tone('sawtooth',f,i===3?260:null,i===3?1:.35,.18,i*.38,{f:1400}))},
 tickHard:()=>{noise(.03,.55,0,'bandpass',3500,null,8);tone('sine',1200,null,.05,.15)},
 impact:()=>{tone('sine',70,30,1,.7);noise(.5,.5,0,'lowpass',300)},
 drumroll:()=>{for(let i=0;i<30;i++)noise(.05,.25+i*.01,i*.05,'bandpass',300,null,1)},
 applause:()=>{for(let i=0;i<60;i++)noise(.03,.2,Math.random()*2.5,'bandpass',1500+Math.random()*2000,null,2)},
 countdown:()=>{[0,1,2].forEach(i=>tone('square',660,null,.15,.2,i));tone('square',1320,null,.5,.25,3)},
 lightning:()=>{noise(1.2,.7,0,'lowpass',3000,100);tone('sine',40,25,1.4,.6)},
 stinger:()=>{noise(.5,.4,0,'bandpass',500,5000,1);tone('sawtooth',110,55,.6,.2,.3,{f:1200});tone('sine',55,40,.8,.5,.3)}};
const FXSFX={countdown:'countdown',eliminated:'buzz',versus:'impact',lowerthird:'whooshBig',panic:'alarm',lightning:'lightning',podium:'drumroll',cashcounter:'cash',confetti:'applause',spotlight:'riser',glitch:'glitchGold',zoompunch:'impact',winner:'vaultOpen',ballthrow:'goal',shockwave:'impact',splitflap:'cascade',stinger:'stinger',moneyrain:'cash',bankopen:'glitchGold',vaultopen:'vaultOpen',code:'codeReveal',win:'cash',goal:'goal',miss:'miss',stamp:'buzz',timeout:'vaultClose',case:'caseOpen'};

/* ---------------- gallery catalogue (shown in the animations section) ---------------- */
const GALLERY=[
 ['countdown','شمارش ۳-۲-۱ «برو!»','اسلم عددها با هاله و بوم'],['versus','ورود دو نفره VS','برش مورب رنگ تیم‌ها + ضربهٔ VS'],['winner','برنده! (کنفتی + پول)','انفجار ذره، بارش اسکناس، بلوم WebGL'],
 ['win','+ثانیه (پانچ عدد)','عدد غول‌پیکر با برق و لرزش دوربین'],['ballthrow','پرتاب توپ · اصلاح‌شده','۲م +۵ · ۳م +۱۰ · ۴م +۲۰ (دورتر = بیشتر)'],['bankopen','گلیچ طلایی «بانک باز شد»','تیکه‌تیکه شدن تصویر + RGB split'],
 ['code','رونمایی رقم رمز','رقم ۴۲۰px با شاین طلایی'],['vaultopen','باز شدن گاوصندوق','چرخش دستگیره، نور طلایی، اسکناس'],['timeout','وقت تمام!','فلش قرمز پالسی'],['panic','حالت پنیک ۱۰ ثانیه','قاب قرمز تپنده، تایمر لرزان'],
 ['eliminated','مهر «حذف شد!»','استمپ ضربه‌ای با شیب'],['stamp','مهر دوباره/رمز غلط','مهر کوچک کنار بازیکن'],['lowerthird','زیرنویس معرفی (لوئر تِرد)','ورود نرم، رنگ برند'],['moneyrain','بارش پول','اسکناس و سکهٔ فیزیکی'],
 ['confetti','توپ‌های کنفتی','دو شلیک از گوشه‌ها'],['lightning','صاعقه','فلش + RGB + غرش'],['spotlight','نورافکن جستجو','تاریکی با دایرهٔ نور متحرک'],['podium','سکوی نفرات','بالا آمدن ستون‌ها'],['cashcounter','شمارندهٔ ثانیه','شمارش سریع تا عدد'],
 ['splitflap','تابلوی فرودگاهی','حروف چرخان'],['stinger','استینگر انتقال','سه نوار رنگی سریع'],['glitch','گلیچ دیجیتال','WebGL glitch'],['shockwave','موج ضربه','اعوجاج WebGL'],['zoompunch','زوم پانچ','ضربهٔ دوربین'],['state','انتقال مرحله','وایپ مورب + عنوان']];

/* ---------------- main frame hook ---------------- */
let lastT=now();
function frame(){const s=V7.S();const c=G2();const sc=c.canvas.width/1920;const tn=now();const dt=Math.min(.05,tn-lastT);lastT=tn;rects.length=0;
 const prog=s.on&&SET.program;
 if(s.state!==lastState){lastState=s.state;sceneT0=tn}
 c.save();c.setTransform(sc,0,0,sc,0,0);c.globalAlpha=1;c.globalCompositeOperation='source-over';c.direction='rtl';c.shadowBlur=0;
 const sh=CAM.shake*Math.max(0,1-(tn-CAM.shakeT)/.5);const zp=CAM.zoom*Math.max(0,1-(tn-CAM.zoomT)/.45);
 if(prog){
  const keyed=SET.key||(window.V7CH&&V7CH.keyOut&&V7CH.keyOut());
  if(keyed){c.fillStyle=(window.V7CH&&V7CH.keyHex&&V7CH.keyHex())||'#00b140';c.fillRect(0,0,1920,1080)}else bg(tn,SET.theme);
  if(window.V7CH&&V7CH.composite){try{V7CH.composite(c)}catch(e){}}
  c.save();if(sh||zp){c.translate(960,540);c.scale(1+zp,1+zp);c.translate(-960+(Math.random()-.5)*sh,-540+(Math.random()-.5)*sh)}
  try{(SC[s.state]||SC.READY)(s,tn-sceneT0)}catch(e){console.warn('[V7GFX scene]',e)}
  c.restore();
  bankTiles(s);mainTimer(s);ribbon(s)}
 c.save();if(sh){c.translate((Math.random()-.5)*sh,(Math.random()-.5)*sh)}drawFX();drawParticles(dt);c.restore();
 if(CAM.flash>0.01){c.fillStyle=hexA(CAM.flashCol.length===7?CAM.flashCol:'#ffffff',CAM.flash);c.fillRect(0,0,1920,1080);CAM.flash*=.86}
 c.restore()}

const V7FX=window.V7FX={C,SET,saveSet,THEMES,GALLERY,sfx:SFX,rects,burst,rain,shake,flash,zoomPunch,
 play(kind,data){onFx(kind,data||{});const n=FXSFX[kind];if(n&&SFX[n]){try{AE.resume().then(()=>SFX[n]())}catch(e){}}},
 fire:onFx,program:()=>SET.program&&V7.S().on,active:()=>FXQ.length>0||PS.length>0,frame,T,U,pill,slab};
V7.on('fx',e=>{try{onFx(e.kind,e.data)}catch(err){console.warn(err)}});

D.whenReady(['draw','cv','g','V7'],()=>{const _draw=draw;draw=function(){_draw.apply(this,arguments);try{frame()}catch(e){console.warn('[V7GFX]',e)}if(window.V7SUB){try{V7SUB.render(G2(),rects)}catch(e){console.warn('[V7SUB]',e)}}if(window.V7GL){try{V7GL.post(G2())}catch(e){}}}});
})();
