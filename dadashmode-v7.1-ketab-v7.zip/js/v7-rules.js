/* DADASHMODE V7.1 · pure rules engine, rebuilt from Director Book V7 (§1.3 source of truth, §3.3–3.7, §4.2–4.3, §4.7, §4.10, §9.4, §9.7).
   Works in the browser (window.V7R) and in Node (globalThis.V7R) for tools/v7-selftest.mjs. */
(function(root){'use strict';
const CFG={start:45,
 r1:{limit:30,hold:2,win:10,fallback:5},
 r2:{throws:3,lines:[{id:'L1',m:2,sec:5,col:'#22c55e',fa:'سبز · ۲ متر'},{id:'L2',m:3,sec:10,col:'#facc15',fa:'زرد · ۳ متر'},{id:'L3',m:4,sec:20,col:'#ef4444',fa:'قرمز · ۴ متر'}]},
 r3:{limit:60,swallow:30,floor:3,cap:20,tieBand:1,tieBonus:5,dqBonus:10,dqNoFinish:5,debrisPenalty:3,safetyBonus:5,noneBonus:5},
 r4:{limit:180,reward:15,fallback:5,chWin:[10,5],chLose:-5,wrongLock:5,finalizeAfter:20},
 reveal:{cap:30},shop:{max:2,maxRed:1,tax:5,floor:20},risk:{stakes:[0,10,20],allin:30,allinGap:15,floor:20},
 vault:{showTarget:5,codeShow:3,memShow:5,memLock:8,checkPenalty:3,riddleLock:5,codeLock:5,hintShow:3},
 subs:{on:true,cps:15}};
const STATES=['READY','R1','R2','R3_SANDWICH','TWIST_BANKOPEN','R4_GLUE','GLUE_CHALLENGE','REVEAL','SHOP','SHOP_REVEAL','RISK','VAULT_ARMED','RUN1','RUN2','CASE','CASE_L1','CASE_L2','CASE_L3','END'];
const STATE_FA={READY:'آماده · بانک ۴۵|۴۵',R1:'راند ۱ · برج لیوان',R2:'راند ۲ · فاصله را خودت انتخاب کن',R3_SANDWICH:'راند ۳ · دوئل ساندویچ',TWIST_BANKOPEN:'پیچش · بانک باز شد',R4_GLUE:'راند ۴ · دستکش، پازل و چسب',GLUE_CHALLENGE:'چالش چسب',REVEAL:'رونمایی بانک · سقف ۳۰',SHOP:'فروشگاه کارت',SHOP_REVEAL:'رونمایی کارت‌ها',RISK:'شوت ریسک',VAULT_ARMED:'آماده‌سازی فینال',RUN1:'فینال · دویدن اول (نفر عقب)',RUN2:'فینال · دویدن دوم (نفر جلو)',CASE:'کیف طلایی',CASE_L1:'لایهٔ ۱ · تاج و نشان ساندویچ طلایی',CASE_L2:'لایهٔ ۲ · پاکت سرنوشت',CASE_L3:'لایهٔ ۳ · پاکت مجازات',END:'پایان · دفاع از تاج'};
const CARDS=[
 {id:'HINT',fa:'ذره‌بین',price:10,color:'blue',icon:'🔍',line:'یک بار کمک',sub:'حافظه یا معما، فقط یک بار.',hud:'🔍 ۱ بار'},
 {id:'SHIELD',fa:'سپر',price:5,color:'blue',icon:'🛡',line:'قرمز را خنثی کن',sub:'بیمهٔ ارزان.',hud:'🛡 سپر'},
 {id:'GLOVES',fa:'دستکش بوکس',short:'دستکش',price:15,color:'red',icon:'🥊',line:'حافظه با دستکش',sub:'حریف اتاق حافظه را با دستکش بوکس انجام می‌دهد.',hud:'🥊 ایستگاه ۲'},
 {id:'SPICY',fa:'معمای تند',price:10,color:'red',icon:'🌶',line:'معمای سخت‌تر',sub:'همان جواب، متن سخت‌تر.',hud:'🌶 معما'},
 {id:'MIRROR',fa:'آینه',price:20,color:'gold',icon:'🪞',line:'قرمز برگردد',sub:'قمار روی ذهن حریف.',hud:'🪞 آینه'}];
/* station 1 · blind drawing pool (16 + 2 callbacks) · accepted one-word guesses */
const TARGETS=[['دوچرخه',['دوچرخه','دوچرخ']],['عینک',['عینک']],['ماهی',['ماهی']],['خانه',['خانه','خونه']],['ساعت',['ساعت']],['چتر',['چتر']],['کلید',['کلید']],['ماشین',['ماشین','خودرو']],['درخت',['درخت']],['خورشید',['خورشید','آفتاب']],['موز',['موز']],['فنجان',['فنجان','فنجون','لیوان']],['گربه',['گربه','پیشی']],['کفش',['کفش']],['موشک',['موشک']],['قلب',['قلب','دل']]].map(([name,accept])=>({name,accept}))
 .concat([{name:'ساندویچ',accept:['ساندویچ'],callback:true},{name:'توپ تنیس',accept:['توپ','توپ تنیس'],callback:true}]);
/* station 3 · funny riddles bucketed by answer 0..9 (normal / spicy / hint) */
const RIDDLES=[
 {id:'R0-01',answer:0,normal:'خروس روی پشت‌بوم چند تا تخم می‌ذاره؟',spicy:'عماد سه تا خروس داره که هر کدوم روزی دو بار روی پشت‌بوم می‌خونن. روی هم چند تا تخم می‌ذارن؟',hint:'خروس، مرغ نیست!'},
 {id:'R1-01',answer:1,normal:'من یه عددم؛ هر چی رو در من ضرب کنی، همون می‌مونه. من چندم؟',spicy:'الیاس ۷۳۹ تا ساندویچ رو در من ضرب کرد و باز همون ۷۳۹ شد. من چندم؟',hint:'ضرب در من هیچی رو عوض نمی‌کنه.'},
 {id:'R2-01',answer:2,normal:'عماد دو تا ساندویچ داشت. یکی رو الیاس خورد، اون یکی رو هم… الیاس خورد! الیاس چند تا خورد؟',spicy:'عماد سه تا ساندویچ داشت؛ الیاس همه رو خورد جز یکی، بعد اون یکی رو نصف کرد و هر دو نصفه رو قایم کرد. چند تیکه قایم شد؟',hint:'فقط بشمار چی رفت پیش الیاس.'},
 {id:'R3-01',answer:3,normal:'سه تا گربه، سه تا موش رو توی سه دقیقه می‌گیرن. چند تا گربه لازمه که صد تا موش رو توی صد دقیقه بگیرن؟',spicy:'سه تا داور هوش مصنوعی، سه تا تقلب رو توی سه ثانیه می‌گیرن. چند تا داور لازمه که نود تا تقلب عماد رو توی نود ثانیه بگیرن؟',hint:'هر گربه هر سه دقیقه یه موش.'},
 {id:'R4-01',answer:4,normal:'میز مسابقه چهار تا پایه داره. اگه الیاس روش بشینه، میز چند تا پایه داره؟',spicy:'عماد یه پایهٔ میز رو لگد می‌زنه، الیاس یکی رو قایم می‌کنه، بعد هر دو برمی‌گردونن سر جاش. آخرش میز چند پایه داره؟',hint:'نشستن و قهر کردن پایه کم نمی‌کنه.'},
 {id:'R5-01',answer:5,normal:'وقتی دستکش بوکس رو درمیاری، دست راستت چند تا انگشت داره؟',spicy:'الیاس با دستکش بوکس داد زد «انگشت ندارم!». وقتی درش آورد، دست چپش چند تا انگشت داشت؟',hint:'دستکش انگشت نمی‌خوره!'},
 {id:'R6-01',answer:6,normal:'بزرگ‌ترین عدد روی یه تاس معمولی چنده؟',spicy:'عماد تاس انداخت و بالاش «یک» اومد. عددِ روی زمین، زیر تاس، چنده؟',hint:'دو روی روبه‌روی تاس، جمعشون هفته.'},
 {id:'R7-01',answer:7,normal:'هفته چند روزه، حتی وقتی عماد می‌گه جمعه حساب نیست؟',spicy:'اگه الیاس هر روز هفته یه ساندویچ بخوره و جمعه‌ها دو تا، توی یک هفته چند «روز» ساندویچ خورده؟',hint:'از شنبه تا جمعه بشمار.'},
 {id:'R8-01',answer:8,normal:'یه عنکبوت چند تا پا داره؟',spicy:'دو تا عنکبوت مسابقه دادن؛ یکی نصف پاهاش رو قایم کرد که ضایع نشه. اونی که تقلب نکرد چند تا پا داره؟',hint:'حشره شیش تا، عنکبوت بیشتر.'},
 {id:'R9-01',answer:9,normal:'من یه عددم؛ اگه سر و ته‌م کنی، شیش می‌شم. من چندم؟',spicy:'عماد با اطمینان گفت «شیش»، ولی کاغذ رو برعکس گرفته بود. عدد واقعی چند بود؟',hint:'کاغذ رو سر و ته کن.'}];
/* case layer 2 · fate envelopes (12) */
const ENVELOPES=[['انتخاب بازی اول','برنده راند یک قسمت بعد را انتخاب می‌کند.'],['شروع با ۵۰ ثانیه','برنده قسمت بعد با ۵۰ ثانیه شروع می‌کند.'],['سپر رایگان','یک سپر مجانی در فروشگاه قسمت بعد.'],['یک راهنمایی از داور','یک بار در قسمت بعد، جمنای راهنمایی می‌کند.'],['انتخاب لباس بازنده','برنده لباس بازنده را برای قسمت بعد انتخاب می‌کند.'],['حق وتو','یک قانون کوچک قسمت بعد را عوض می‌کند (با تأیید کارگردان).'],['ناهار با بازنده','بازنده ناهار روز ضبط بعد را می‌دهد.'],['اول انتخاب خط','در راند فاصلهٔ قسمت بعد، اول انتخاب می‌کند.'],['پاکت پوچ','هیچ! فقط افتخار.'],['سؤال کامنت‌ها','بازنده به یک سؤال منتخب کامنت‌ها جواب می‌دهد.'],['دستکش افتخاری','بازنده راند اول قسمت بعد را با دستکش شروع می‌کند.'],['تاج دو هفته','تاج تا ضبط بعد پیش برنده می‌ماند.']].map(([title,desc])=>({title,desc}));
/* case layer 3 · loser envelope = mystery bite punishment (book §4.10الف: loser picks 2 of 6, then all 6 are shown) */
const BITES=[['🥒','خیارشور ترش'],['🍋','برش لیموترش'],['🧅','تکهٔ کوچک پیاز خام'],['🍫','شکلات · شانس آوردی'],['🌭','یک قاشق خردل'],['🍞','نان خالی · پوچ']].map(([emoji,title],i)=>({n:i+1,emoji,title}));
const card=id=>CARDS.find(c=>c.id===id);
const r1d=x=>Math.round(x*10)/10;const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function leaderOf(b){const ids=Object.keys(b);if(ids.length<2||b[ids[0]]===b[ids[1]])return null;return b[ids[0]]>b[ids[1]]?ids[0]:ids[1]}
/* R1 · first valid tower +10; nobody: more complete layers +5 (equal → nothing). Returns a plain award map. */
function r1Score(o,cfg=CFG){if(o&&o.winner)return {[o.winner]:cfg.r1.win};const a=(o&&o.layers)||{};const ids=Object.keys(a);if(ids.length<2||a[ids[0]]===a[ids[1]])return {};return {[a[ids[0]]>a[ids[1]]?ids[0]:ids[1]]:cfg.r1.fallback}}
/* R2 · line value; throw order = trailing player first (book §3.4); equal banks → null (director decides) */
function r2Value(lineId,cfg=CFG){const l=cfg.r2.lines.find(x=>x.id===lineId);return l?l.sec:0}
function r2Order(choice,banks){const ids=Object.keys(choice||{});if(ids.length<2||!banks)return null;const l=leaderOf(banks);if(!l)return null;const t=ids.find(i=>i!==l);return [t,l]}
/* R3 · speed sandwich */
function r3Score(p,opts={},cfg=CFG){const c=cfg.r3;const ids=Object.keys(p);const [a,b]=ids;
 if(opts.safety)return {awards:{[a]:c.safetyBonus,[b]:c.safetyBonus},note:'SAFETY_STOP'};
 const dq=ids.filter(i=>p[i].status==='dq');if(dq.length===2)return {awards:{},note:'BOTH_DQ'};
 if(dq.length===1){const o=ids.find(i=>i!==dq[0]);const pts=p[o].status==='final'?c.dqBonus:c.dqNoFinish;return {awards:{[o]:pts},winner:o,note:'DQ_'+dq[0],points:pts}}
 const fin=ids.filter(i=>p[i].status==='final');
 if(!fin.length){if(!opts.pick)return {need:'pick',awards:{},note:'NOBODY_FINISHED'};if(opts.pick==='equal')return {awards:{},note:'NONE_EQUAL'};return {awards:{[opts.pick]:c.noneBonus},note:'NONE_LESS_LEFT',points:c.noneBonus}}
 const T=i=>p[i].status==='final'?r1d((+p[i].T||0)+(+p[i].pen||0)):c.limit;const Ta=T(a),Tb=T(b);const delta=r1d(Math.abs(Ta-Tb));
 if(delta<c.tieBand)return {awards:{[a]:c.tieBonus,[b]:c.tieBonus},delta,winner:'TIE',times:{[a]:Ta,[b]:Tb},note:'TIE_UNDER_1S',points:c.tieBonus};
 const w=Ta<Tb?a:b;const pts=clamp(Math.round(delta),c.floor,c.cap);return {awards:{[w]:pts},delta,winner:w,times:{[a]:Ta,[b]:Tb},note:'WIN_BY_DIFF',points:pts}}
/* R4 · first valid finish +15; glue challenge win → challenger 10 / first 5; lose → challenger −5; nobody → +5 to the more correct puzzle */
function r4Score(o,cfg=CFG){const c=cfg.r4;const aw={};
 if(!o.first){const k=o.correct||{};const ids=Object.keys(k);if(ids.length===2&&k[ids[0]]!==k[ids[1]])aw[k[ids[0]]>k[ids[1]]?ids[0]:ids[1]]=c.fallback;return aw}
 const ch=o.challenge;const res=ch&&ch.by&&ch.by!==o.first?(o.touched?'win':ch.result):null;
 if(res==='win'){aw[o.first]=c.chWin[1];aw[ch.by]=c.chWin[0];return aw}
 aw[o.first]=c.reward;if(res==='lose')aw[ch.by]=c.chLose;return aw}
function gapCap(b,cfg=CFG){const [x,y]=Object.keys(b);const gap=Math.abs(b[x]-b[y]);if(gap<=cfg.reveal.cap)return {apply:false,gap};const lead=b[x]>b[y]?x:y,trail=lead===x?y:x;return {apply:true,gap,trail,lead,newTrail:b[lead]-cfg.reveal.cap,delta:b[lead]-cfg.reveal.cap-b[trail]}}
function price(cardId,pid,banks,cfg=CFG){const c=card(cardId);if(!c)return 0;return c.price+((c.color==='red'||c.color==='gold')&&leaderOf(banks)===pid?cfg.shop.tax:0)}
function shopAvail(pid,picks,banks,cfg=CFG){const mine=picks||[];const spent=mine.reduce((s,id)=>s+price(id,pid,banks,cfg),0);const out={};
 for(const c of CARDS){const pr=price(c.id,pid,banks,cfg);let ok=true,reason='';
  if(mine.includes(c.id)){ok=false;reason='انتخاب شد'}else if(mine.length>=cfg.shop.max){ok=false;reason='۲ کارت پر'}
  else if(c.color==='red'&&mine.some(id=>card(id).color==='red')){ok=false;reason='قرمز پر شد'}else if(banks[pid]-spent-pr<cfg.shop.floor){ok=false;reason='کف ۲۰'}
  out[c.id]={ok,reason,price:pr,tax:pr-c.price}}return out}
function shopResolve(picks,banks,cfg=CFG){const ids=Object.keys(picks);const opp=p=>ids.find(i=>i!==p);const costs={},log=[],labels=[],eff={};
 ids.forEach(p=>{eff[p]={gloves:false,spicy:false,hint:0};costs[p]=(picks[p]||[]).reduce((s,id)=>s+price(id,p,banks,cfg),0)});
 const has=(p,id)=>(picks[p]||[]).includes(id);const usedShield={},usedMirror={};
 ids.forEach(p=>{if(has(p,'HINT')){eff[p].hint=1;labels.push({by:p,card:'HINT',target:p,res:'ACTIVE'})}});
 for(const p of ids)for(const id of (picks[p]||[])){if(card(id).color!=='red')continue;let target=opp(p),res='ACTIVE';
  if(has(target,'MIRROR')&&!usedMirror[target]){usedMirror[target]=true;target=p;res='BOUNCED'}
  if(has(target,'SHIELD')&&!usedShield[target]){usedShield[target]=true;labels.push({by:p,card:id,target,res:'BLOCKED',bounced:res==='BOUNCED'});log.push(`${id} ${p}→${target} BLOCKED`);continue}
  if(id==='GLOVES')eff[target].gloves=true;if(id==='SPICY')eff[target].spicy=true;labels.push({by:p,card:id,target,res,bounced:res==='BOUNCED'});log.push(`${id} ${p}→${target} ${res}`)}
 ids.forEach(p=>{if(has(p,'SHIELD')&&!usedShield[p])labels.push({by:p,card:'SHIELD',target:p,res:'BURNED'});if(has(p,'MIRROR')&&!usedMirror[p])labels.push({by:p,card:'MIRROR',target:p,res:'BURNED'})});
 return {costs,labels,effects:eff,log,none:ids.every(p=>!(picks[p]||[]).length)}}
function riskOptions(pid,banks,cfg=CFG){const o=Object.keys(banks).find(i=>i!==pid);const behind=banks[o]-banks[pid];const out={};
 for(const s of cfg.risk.stakes){const ok=banks[pid]-s>=cfg.risk.floor;out[s]={ok,reason:ok?'':'کف ۲۰'}}
 const okA=behind>=cfg.risk.allinGap&&banks[pid]-cfg.risk.allin>=cfg.risk.floor;out[cfg.risk.allin]={ok:okA,allin:true,reason:okA?'':(behind<cfg.risk.allinGap?'فقط نفر ۱۵+ عقب':'کف ۲۰')};return out}
function riskOrder(banks){const l=leaderOf(banks);const ids=Object.keys(banks);if(!l)return ids.includes('M')?['M',ids.find(i=>i!=='M')]:ids;return [ids.find(i=>i!==l),l]}
/* memory room pattern: 8 cups, 3..5 gold, never more than 3 same colour in a row */
function prng(seed){let a=seed>>>0||1;return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function memPattern(seed){const r=prng(seed);for(let n=0;n<999;n++){const p=Array.from({length:8},()=>r()<.5?1:0);const g=p.reduce((a,b)=>a+b,0);if(g<3||g>5)continue;let run=1,ok=true;for(let i=1;i<8;i++){run=p[i]===p[i-1]?run+1:1;if(run>3){ok=false;break}}if(ok)return p}return [1,0,1,1,0,0,1,0]}
function memCheck(a,b){let n=0;for(let i=0;i<8;i++)if((a[i]?1:0)===(b[i]?1:0))n++;return n}
function riddlePick(d,pool=RIDDLES){return pool.find(r=>r.answer===+d&&!r.used)||null}
function riddleText(r,eff){return r?(eff&&eff.spicy?r.spicy:r.normal):''}
const normFa=s=>String(s||'').replace(/[\u064B-\u0652\u0670]/g,'').replace(/\u200c/g,'').replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/[.,!?؟،«»"':]/g,' ').trim();
const STOP=new Set(['فکر','کنم','میکنم','این','اینه','یه','یک','شاید','احتمالا','باشه','هست','است','هستش','خب','خوب','به','نظرم','من','که','اون']);
function judgeWord(target,said){const t=TARGETS.find(x=>x.name===target);const acc=(t?t.accept:[target]).map(normFa);const words=normFa(said).split(/\s+/).filter(w=>w&&!STOP.has(w));const word=words[0]||'';return {ok:acc.includes(word),word}}
function sha256(ascii){const rr=(v,a)=>(v>>>a)|(v<<(32-a));const mp=Math.pow,mw=mp(2,32);let i,j,res='';const words=[],bl=ascii.length*8;const hash=[],k=[];let pc=0;const comp={};
 for(let c=2;pc<64;c++){if(!comp[c]){for(i=0;i<313;i+=c)comp[i]=c;hash[pc]=(mp(c,.5)*mw)|0;k[pc++]=(mp(c,1/3)*mw)|0}}
 ascii+='\x80';while(ascii.length%64-56)ascii+='\x00';for(i=0;i<ascii.length;i++){j=ascii.charCodeAt(i);if(j>>8)return '';words[i>>2]|=j<<((3-i)%4)*8}
 words[words.length]=((bl/mw)|0);words[words.length]=bl;let H=hash.slice(0,8);
 for(j=0;j<words.length;){const w=words.slice(j,j+=16);const old=H;H=H.slice(0,8);
  for(i=0;i<64;i++){const w15=w[i-15],w2=w[i-2];const a=H[0],e=H[4];
   const t1=H[7]+(rr(e,6)^rr(e,11)^rr(e,25))+((e&H[5])^((~e)&H[6]))+k[i]+(w[i]=(i<16)?w[i]:(w[i-16]+(rr(w15,7)^rr(w15,18)^(w15>>>3))+w[i-7]+(rr(w2,17)^rr(w2,19)^(w2>>>10)))|0);
   const t2=(rr(a,2)^rr(a,13)^rr(a,22))+((a&H[1])^(a&H[2])^(H[1]&H[2]));H=[(t1+t2)|0].concat(H);H[4]=(H[4]+t1)|0}
  for(i=0;i<8;i++)H[i]=(H[i]+old[i])|0}
 for(i=0;i<8;i++)for(j=3;j+1;j--){const b=(H[i]>>(j*8))&255;res+=(b<16?'0':'')+b.toString(16)}return res}
async function sealHash(code,salt){const s=String(code)+String(salt);try{const sub=root.crypto&&root.crypto.subtle;if(sub){const d=await sub.digest('SHA-256',new TextEncoder().encode(s));return Array.from(new Uint8Array(d)).map(b=>b.toString(16).padStart(2,'0')).join('').slice(0,6).toUpperCase()}}catch(e){}return sha256(s).slice(0,6).toUpperCase()}
/* final ranking: opened beats not opened · more time left wins · equal time (0.1s) → sudden death · nobody opened → more codes, else sudden death */
function finalRank(runs){const E=runs.E,M=runs.M;if(!E||!M)return {winner:null,why:'INCOMPLETE'};
 if(E.opened&&!M.opened)return {winner:'E',why:'OPENED'};if(M.opened&&!E.opened)return {winner:'M',why:'OPENED'};
 if(E.opened&&M.opened){if(Math.abs((E.left||0)-(M.left||0))<0.05)return {winner:null,why:'SUDDEN_DEATH_TIME'};return {winner:E.left>M.left?'E':'M',why:'MORE_TIME'}}
 if((E.codes||0)!==(M.codes||0))return {winner:(E.codes||0)>(M.codes||0)?'E':'M',why:'MORE_CODES'};return {winner:null,why:'SUDDEN_DEATH_CODES'}}
const V7R={CFG,STATES,STATE_FA,CARDS,TARGETS,RIDDLES,ENVELOPES,BITES,card,leaderOf,r1Score,r2Value,r2Order,r3Score,r4Score,gapCap,price,shopAvail,shopResolve,riskOptions,riskOrder,memPattern,memCheck,riddlePick,riddleText,judgeWord,sealHash,finalRank,_sha256:sha256};
root.V7R=V7R;if(typeof module!=='undefined'&&module.exports)module.exports=V7R;
})(typeof globalThis!=='undefined'?globalThis:window);
