/**
 * DADASHMODE V7 Multi-Voice System
 * Professional female voice options for Nila (judge/co-host)
 * Switchable at runtime with preview capability
 */

class VoiceProfile {
  constructor(id,name,language='fa',gender='female',tone='professional',speed=1.0){
    this.id=id;
    this.name=name;
    this.language=language;
    this.gender=gender;
    this.tone=tone;
    this.speed=speed;
    this.provider='native'; // 'native','cloud','webgl'
    this.pitch=1.0;
    this.volume=1.0;
    this.enabled=true
  }
}

class VoiceLibrary {
  constructor(){
    this.voices={};
    this.currentVoice=null;
    this.initializeDefaultVoices()
  }

  initializeDefaultVoices(){
    // Professional female voices for Nila
    this.register(new VoiceProfile(
      'nila-professional',
      'نیلا (حرفه‌ای)',
      'fa','female','professional',1.0
    ));
    this.register(new VoiceProfile(
      'nila-warm',
      'نیلا (گرم و دوستانه)',
      'fa','female','warm',0.95
    ));
    this.register(new VoiceProfile(
      'nila-bold',
      'نیلا (قاطع و محکم)',
      'fa','female','bold',1.05
    ));
    this.register(new VoiceProfile(
      'nila-energetic',
      'نیلا (پرانرژی)',
      'fa','female','energetic',1.1
    ));
    this.register(new VoiceProfile(
      'nila-calm',
      'نیلا (آرام و متدولوژیک)',
      'fa','female','calm',0.9
    ));
    this.register(new VoiceProfile(
      'nila-dramatic',
      'نیلا (درام و تئاتریکال)',
      'fa','female','dramatic',1.15
    ));
    this.currentVoice=this.voices['nila-professional']
  }

  register(profile){
    this.voices[profile.id]=profile;
    console.log(`✓ Voice registered: ${profile.name}`)
  }

  getVoice(id){
    return this.voices[id]||this.currentVoice
  }

  setCurrentVoice(id){
    const voice=this.getVoice(id);
    if(voice){
      this.currentVoice=voice;
      console.log(`Voice switched to: ${voice.name}`)
    }
    return this.currentVoice
  }

  listVoices(){
    return Object.values(this.voices).map(v=>({
      id:v.id,name:v.name,tone:v.tone,speed:v.speed
    }))
  }

  getVoicesByTone(tone){
    return Object.values(this.voices).filter(v=>v.tone===tone)
  }
}

class NativeVoiceEngine {
  constructor(){
    this.synth=window.speechSynthesis;
    this.supported=!!this.synth;
    this.currentUtterance=null;
    this.isPlaying=false
  }

  speak(text,profile){
    if(!this.supported)return console.warn('Speech synthesis not supported');
    if(this.isPlaying)this.stop();
    const utterance=new SpeechSynthesisUtterance(text);
    utterance.lang=profile.language;
    utterance.rate=profile.speed;
    utterance.pitch=profile.pitch;
    utterance.volume=profile.volume;
    utterance.onstart=()=>{this.isPlaying=true};
    utterance.onend=()=>{this.isPlaying=false};
    utterance.onerror=(e)=>{console.error('Speech error:',e)};
    this.currentUtterance=utterance;
    this.synth.speak(utterance)
  }

  stop(){
    if(this.supported){
      this.synth.cancel();
      this.isPlaying=false
    }
  }

  isSupported(){
    return this.supported
  }

  isSpeaking(){
    return this.isPlaying
  }
}

class CloudVoiceEngine {
  constructor(apiKey=''){
    this.apiKey=apiKey;
    this.provider='google'; // or 'azure','amazon'
    this.isPlaying=false
  }

  async speak(text,profile){
    // Placeholder for cloud TTS integration
    // In production: call Google Cloud TTS, Azure Speech, or Amazon Polly
    console.log(`Cloud TTS (${this.provider}): ${text} [${profile.name}]`);
    try{
      const response=await this.requestTTS(text,profile);
      this.playAudio(response.audioContent)
    }catch(e){
      console.error('Cloud TTS error:',e)
    }
  }

  async requestTTS(text,profile){
    // Stub for actual API call
    return {audioContent:null}
  }

  playAudio(audioData){
    // Stub for audio playback
    this.isPlaying=true
  }

  stop(){
    this.isPlaying=false
  }
}

class NilaVoiceManager {
  constructor(){
    this.library=new VoiceLibrary();
    this.nativeEngine=new NativeVoiceEngine();
    this.cloudEngine=new CloudVoiceEngine();
    this.useCloud=false;
    this.dialogueCache={};
    this.history=[]
  }

  setVoice(id){
    this.library.setCurrentVoice(id)
  }

  getCurrentVoice(){
    return this.library.currentVoice
  }

  listAvailableVoices(){
    return this.library.listVoices()
  }

  async speak(text,voiceId=null){
    const voice=voiceId?this.library.getVoice(voiceId):this.library.currentVoice;
    if(!voice||!voice.enabled)return;
    
    // Log to history
    this.history.push({
      text,voiceId:voice.id,timestamp:Date.now()
    });

    if(this.useCloud){
      await this.cloudEngine.speak(text,voice)
    }else{
      this.nativeEngine.speak(text,voice)
    }
  }

  async speakLine(lineKey,voiceId=null){
    // Speak a named dialogue line
    const dialogue=this.getDialogue(lineKey);
    if(dialogue){
      await this.speak(dialogue,voiceId)
    }
  }

  getDialogue(key){
    // Stub: load from dialogue database
    return this.dialogueCache[key]||key
  }

  preloadDialogue(dialogueMap){
    this.dialogueCache={...this.dialogueCache,...dialogueMap}
  }

  stop(){
    if(this.useCloud){
      this.cloudEngine.stop()
    }else{
      this.nativeEngine.stop()
    }
  }

  isSpeaking(){
    return this.useCloud?this.cloudEngine.isPlaying:this.nativeEngine.isSpeaking()
  }

  previewVoice(voiceId){
    // Play a preview of the voice
    const voice=this.library.getVoice(voiceId);
    const previewText='سلام، من نیلا هستم. بیایید این چالش را شروع کنیم.';
    this.speak(previewText,voiceId)
  }

  getVoiceMetadata(voiceId){
    const voice=this.library.getVoice(voiceId);
    return {
      id:voice.id,
      name:voice.name,
      tone:voice.tone,
      speed:voice.speed,
      language:voice.language
    }
  }

  useCloudTTS(enable){
    this.useCloud=enable;
    console.log(`Switched to ${enable?'cloud':'native'} TTS`)
  }
}

class VoiceUIController {
  constructor(voiceManager){
    this.manager=voiceManager;
    this.container=null
  }

  createVoiceSelector(){
    const container=document.createElement('div');
    container.className='voice-selector';
    container.innerHTML=`
      <div class="voice-header">
        <h3>صدای نیلا</h3>
        <p>صدای مجری و داور را انتخاب کنید</p>
      </div>
      <div class="voice-options"></div>
      <div class="voice-controls">
        <button class="voice-preview-btn">پیش‌نمایش</button>
        <button class="voice-apply-btn">تطبیق</button>
      </div>
    `;
    
    const optionsContainer=container.querySelector('.voice-options');
    this.manager.listAvailableVoices().forEach(voice=>{
      const option=document.createElement('label');
      option.className='voice-option';
      option.innerHTML=`
        <input type="radio" name="nila-voice" value="${voice.id}">
        <div class="voice-label">
          <span class="voice-name">${voice.name}</span>
          <span class="voice-tone">${voice.tone}</span>
        </div>
      `;
      optionsContainer.appendChild(option)
    });

    container.querySelector('.voice-preview-btn').addEventListener('click',()=>{
      const selected=container.querySelector('input[name="nila-voice"]:checked');
      if(selected){
        this.manager.previewVoice(selected.value)
      }
    });

    container.querySelector('.voice-apply-btn').addEventListener('click',()=>{
      const selected=container.querySelector('input[name="nila-voice"]:checked');
      if(selected){
        this.manager.setVoice(selected.value);
        console.log('Voice applied')
      }
    });

    this.container=container;
    return container
  }

  updateCurrentVoiceDisplay(){
    const current=this.manager.getCurrentVoice();
    const input=document.querySelector(`input[value="${current.id}"]`);
    if(input)input.checked=true
  }
}

// Global initialization
window.voiceManager=new NilaVoiceManager();
window.VoiceUIController=VoiceUIController;
window.VoiceLibrary=VoiceLibrary;

// Preset to current voice for episode/game
window.setNilaVoice=function(voiceId){
  window.voiceManager.setVoice(voiceId);
  console.log(`Nila voice set to: ${window.voiceManager.getCurrentVoice().name}`)
};

window.getNilaVoices=function(){
  return window.voiceManager.listAvailableVoices()
};

