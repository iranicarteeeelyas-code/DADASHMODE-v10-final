/* DADASHMODE v7 · subtitle engine (§9.3): on/off (C), per speaker, speed 8–25 cps ([ ]), size 24–96 (- =), offset −2..+2 (Shift+[ ]),
   modes all/word/typewriter/karaoke, position bottom/top, bg none/shadow/box, clean-record, SRT+WebVTT export, WebGL glow/shimmer/wave-in.
   Never covers timers / bank tiles (collision → moves to the other edge). Also takes over v5 subtitle drawing (optional). */
(function(){'use strict';const D=window.DM5;const LS='v7-subs';
const DEF={on:true,cps:15,mode:'karaoke',size:52,pos:'bottom',offset:0,bg:'box',opacity:.82,clean:false,gl:true,glow:.8,shim:.6,takeover:true,spk:{'جمنای':true,'الیاس':true,'عماد':true,'اپ':true,'کارگردان':true}};
const CFG=Object.assign({},DEF,(()=>{try{return JSON.parse(localStorage.getItem(LS)||'{}')}catch(e){return {}}})());
const COL={'جمنای':'#a06bff','الیاس':'#ff2e4d','عماد':'#19e27a','اپ':'#2f7bff','کارگردان':'#f5b82e'};
const save=()=>{try{localStorage.setItem(LS,JSON.stringify(CFG))}catch(e){}};const cues=[];let cur=null,silent=false,fade=1,lastV5='';const t0=Date.now();
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function push(speaker,text,o={}){if(!text)return;const name=String(speaker||'اپ');const words=String(text).trim();const dur=Math.min(7,Math.max(1.5,words.length/CFG.cps));const s=Date.now()/1000+CFG.offset;
 const c={speaker:name,text:words,s,e:s+dur,kind:o.kind||''};cues.push(c);if(cues.length>2000)cues.shift();if(cur&&cur.e>s)cur.e=Math.max(cur.s+.8,s);cur=c}
function split(text){const w=text.split(/\s+/);const L=[];let l='';for(const x of w){if((l+' '+x).trim().length>42&&l){L.push(l);l=x}else l=(l+' '+x).trim()}if(l)L.push(l);return L.slice(-2)}
let off=null;
function render(ctx,rects){const now=Date.now()/1000;const show=CFG.on&&!silent&&cur&&now>=cur.s&&now<=cur.e+.2&&CFG.spk[cur.speaker]!==false;fade+=((show?1:0)-fade)*.25;if(!cur||fade<.02||CFG.clean)return;
 const W=1920,Hh=1080,sc=ctx.canvas.width/1920;if(!off){off=document.createElement('canvas')}if(off.width!==ctx.canvas.width){off.width=ctx.canvas.width;off.height=ctx.canvas.height}const o=off.getContext('2d');o.setTransform(1,0,0,1,0,0);o.clearRect(0,0,off.width,off.height);o.setTransform(sc,0,0,sc,0,0);o.direction='rtl';
 const size=CFG.size,lines=split(cur.text),lh=size*1.45,h=lines.length*lh+size*.8;o.font=`800 ${size}px Vazirmatn`;const bw=Math.max(...lines.map(l=>o.measureText(l).width))+size*1.6;
 let y=CFG.pos==='top'?110:1080-70-h;const hit=r=>!(960+bw/2<r.x||960-bw/2>r.x+r.w||y+h<r.y||y>r.y+r.h);if((rects||[]).some(hit))y=CFG.pos==='top'?1080-70-h:230;
 const col=COL[cur.speaker]||'#fbf7ee';const p=clamp((now-cur.s)/Math.max(.5,cur.e-cur.s),0,1);
 if(CFG.bg==='box'){o.fillStyle=`rgba(7,9,26,${CFG.opacity})`;o.beginPath();o.roundRect(960-bw/2,y,bw,h,size*.4);o.fill()}
 o.font=`900 ${size*.55}px Vazirmatn`;const nw=o.measureText(cur.speaker).width+size*.8;o.fillStyle=col;o.beginPath();o.roundRect(960+bw/2-nw-size*.3,y-size*.55,nw,size*.9,size*.3);o.fill();o.fillStyle='#07091a';o.textAlign='center';o.textBaseline='middle';o.fillText(cur.speaker,960+bw/2-nw/2-size*.3,y-size*.1);
 o.font=`800 ${size}px Vazirmatn`;const total=lines.join(' ').length;let acc=0;
 lines.forEach((l,i)=>{const ly=y+size*.4+lh*i+lh/2;const lp=clamp((p*total-acc)/l.length,0,1);acc+=l.length;let txt=l;
  if(CFG.mode==='typewriter')txt=l.slice(0,Math.ceil(l.length*lp));if(CFG.mode==='word'){const ws=l.split(' ');txt=ws.slice(0,Math.ceil(ws.length*lp)).join(' ')}
  if(CFG.bg==='shadow'){o.shadowColor='rgba(0,0,0,.9)';o.shadowBlur=size*.3}o.lineWidth=size*.12;o.strokeStyle='#07091a';o.lineJoin='round';o.strokeText(txt,960,ly);o.fillStyle=CFG.mode==='karaoke'?'rgba(251,247,238,.55)':'#fbf7ee';o.fillText(txt,960,ly);o.shadowBlur=0;
  if(CFG.mode==='karaoke'){const w=o.measureText(l).width;o.save();o.beginPath();o.rect(960+w/2-w*lp-2,ly-lh/2,w*lp+4,lh);o.clip();o.fillStyle='#ffd60a';o.fillText(l,960,ly);o.restore()}});
 let src=off;if(CFG.gl&&window.V7GL){const L=V7GL.layer(off,{glow:CFG.glow,shim:CFG.shim,wave:1,rgb:0,inP:clamp((now-cur.s)/.25,0,1),gcol:[1,.84,.2]});if(L)src=L}
 ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=fade;ctx.drawImage(src,0,0);ctx.restore()}
const ts=(x,v)=>{x=Math.max(0,x-t0/1000);const h=Math.floor(x/3600),m=Math.floor(x%3600/60),s=Math.floor(x%60),ms=Math.round((x%1)*1000);return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}${v?'.':','}${String(ms).padStart(3,'0')}`};
const srt=()=>cues.map((c,i)=>`${i+1}\n${ts(c.s)} --> ${ts(c.e)}\n${c.speaker}: ${c.text}\n`).join('\n');
const vtt=()=>'WEBVTT\n\n'+cues.map(c=>`${ts(c.s,1)} --> ${ts(c.e,1)}\n<v ${c.speaker}>${c.text}\n`).join('\n');
const PRESETS={main:{size:52,pos:'bottom',on:true,clean:false},shorts:{size:72,pos:'bottom',on:true,clean:false},rehearsal:{size:40,pos:'top',on:true,clean:false},off:{on:false}};
const V7SUB=window.V7SUB={CFG,save,push,render,srt,vtt,cues,PRESETS,
 silence(b){silent=!!b},set(k,v){CFG[k]=v;save()},preset(n){Object.assign(CFG,PRESETS[n]||{});save();D.toast('پریست زیرنویس: '+n)},
 publicState(){return {on:CFG.on,cps:CFG.cps,mode:CFG.mode,size:CFG.size,pos:CFG.pos,offset:CFG.offset,clean:CFG.clean}},
 download(kind){const b=new Blob([kind==='vtt'?vtt():srt()],{type:'text/plain'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='dadashmode-v7-subs.'+(kind||'srt');a.click()}};
addEventListener('keydown',e=>{if(e.target.matches&&e.target.matches('input,textarea,select'))return;if(!(window.V7&&V7.S().on))return;let h=true;
 if(e.code==='KeyC'&&!e.shiftKey){CFG.on=!CFG.on;D.toast('زیرنویس '+(CFG.on?'روشن':'خاموش'))}else if(e.code==='KeyC'&&e.shiftKey){const ks=Object.keys(PRESETS);V7SUB.preset(ks[(ks.indexOf(CFG._p||'main')+1)%ks.length]);CFG._p=ks[(ks.indexOf(CFG._p||'main')+1)%ks.length]}
 else if(e.code==='BracketLeft'&&e.shiftKey)CFG.offset=Math.max(-2,+(CFG.offset-.1).toFixed(1));else if(e.code==='BracketRight'&&e.shiftKey)CFG.offset=Math.min(2,+(CFG.offset+.1).toFixed(1));
 else if(e.code==='BracketLeft')CFG.cps=Math.max(8,CFG.cps-1);else if(e.code==='BracketRight')CFG.cps=Math.min(25,CFG.cps+1);else if(e.code==='Minus')CFG.size=Math.max(24,CFG.size-4);else if(e.code==='Equal')CFG.size=Math.min(96,CFG.size+4);else h=false;
 if(h){save();e.preventDefault();e.stopImmediatePropagation();if(e.code!=='KeyC')D.toast(`زیرنویس · سرعت ${CFG.cps} · اندازه ${CFG.size} · آفست ${CFG.offset}`)}},true);
D.whenReady(['drawSub','st'],()=>{const _ds=drawSub;drawSub=function(seg){if(!CFG.takeover)return _ds.apply(this,arguments);try{const ln=st.line;const key=ln&&ln.text?ln.text+'|'+st.lineT0:'';if(key&&key!==lastV5){lastV5=key;let sp='اپ';try{const x=spk(ln.speaker);if(x)sp=x.name}catch(e){}push(sp,ln.text,{kind:'v5'});if(cur)cur.e=cur.s+Math.max(1.5,Math.min(7,st.lineDur||cur.e-cur.s))}}catch(e){return _ds.apply(this,arguments)}}});
})();
