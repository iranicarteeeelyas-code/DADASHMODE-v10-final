/* DADASHMODE v7 · WebGL post-processing for the program output
   shockwave ripples (×4), RGB split, block glitch, 13-tap bloom, film grain, vignette, lens warp, cinematic grade (lift/gamma/gain + warmth).
   Also exposes V7GL.layer(srcCanvas, params) used by the subtitle engine for glow / shimmer / wave-in / glitch text.
   Skips itself automatically on a keyed (green) output so the key colour stays pure. */
(function(){
'use strict';
const LS='v7-gl';const SET=Object.assign({on:true,bloom:.35,grain:.05,vignette:.35,ca:0,warp:0,lift:0,gamma:1,gain:1,warm:0,sat:1.05,scan:0},(()=>{try{return JSON.parse(localStorage.getItem(LS)||'{}')}catch(e){return {}}})());
const save=()=>{try{localStorage.setItem(LS,JSON.stringify(SET))}catch(e){}};
let cv=null,gl=null,prog=null,lprog=null,tex=null,tex2=null,buf=null,ok=null;
const shocks=[];const K={rgb:0,glitch:0,bloom:0};
const VS=`attribute vec2 p;varying vec2 v;void main(){v=p*.5+.5;gl_Position=vec4(p,0.,1.);}`;
const FS=`precision mediump float;varying vec2 v;uniform sampler2D T;uniform vec2 R;uniform float t,rgb,glitch,bloom,grain,vig,warp,lift,gam,gain,warm,sat,scan;uniform vec4 S[4];
float h(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}
void main(){vec2 uv=vec2(v.x,1.-v.y);
 if(warp>0.){vec2 c=uv-.5;uv=.5+c*(1.+warp*dot(c,c));}
 for(int i=0;i<4;i++){vec4 s=S[i];if(s.w<=0.)continue;vec2 d=uv-s.xy;d.x*=R.x/R.y;float r=length(d);float w=s.z;float band=smoothstep(w-.06,w,r)*(1.-smoothstep(w,w+.06,r));uv-=normalize(d+1e-5)*band*.03*s.w*vec2(R.y/R.x,1.);}
 if(glitch>0.){float row=floor(uv.y*24.+floor(t*18.));float g=step(1.-glitch*.35,h(vec2(row,floor(t*20.))));uv.x+=g*(h(vec2(row,t))-.5)*.12*glitch;}
 float ca=rgb*.012;vec3 col=vec3(texture2D(T,uv+vec2(ca,0.)).r,texture2D(T,uv).g,texture2D(T,uv-vec2(ca,0.)).b);
 if(bloom>0.){vec3 b=vec3(0.);float tot=0.;for(int x=-3;x<=3;x++)for(int y=-3;y<=3;y++){if(abs(float(x))+abs(float(y))>4.)continue;vec2 o=vec2(float(x),float(y))*vec2(6./R.x,6./R.y)*2.2;vec3 s=texture2D(T,uv+o).rgb;b+=max(s-.62,0.)*1.6;tot+=1.;}col+=b/tot*bloom*2.2;}
 col=pow(max(col*gain+lift,0.),vec3(1./gam));col.r+=warm*.06;col.b-=warm*.06;float l=dot(col,vec3(.299,.587,.114));col=mix(vec3(l),col,sat);
 if(scan>0.)col*=1.-scan*.18*(.5+.5*sin(uv.y*R.y*1.6));
 if(vig>0.){vec2 c=uv-.5;col*=1.-vig*smoothstep(.25,.85,length(c*vec2(1.1,1.)));}
 if(grain>0.)col+=(h(uv*R+t*60.)-.5)*grain;
 gl_FragColor=vec4(col,1.);}`;
/* layer shader (subtitles): glow + shimmer + wave-in + rgb */
const LFS=`precision mediump float;varying vec2 v;uniform sampler2D T;uniform vec2 R;uniform float t,glow,shim,wave,rgb,inP;uniform vec3 gcol;
void main(){vec2 uv=vec2(v.x,1.-v.y);float w=(1.-inP)*wave;uv.x+=sin(uv.y*60.+t*8.)*.004*w;uv.y+=(1.-inP)*.02*wave;
 float ca=rgb*.004;vec4 c=texture2D(T,uv);c.r=texture2D(T,uv+vec2(ca,0.)).r;c.b=texture2D(T,uv-vec2(ca,0.)).b;
 float a=0.;for(int x=-4;x<=4;x++)for(int y=-2;y<=2;y++){a+=texture2D(T,uv+vec2(float(x)*3./R.x,float(y)*3./R.y)).a;}a/=45.;
 vec3 gc=gcol*a*glow;float s=0.;if(shim>0.){float p=fract(t*.35)*1.6-.3;s=smoothstep(.06,0.,abs(uv.x-p-uv.y*.15))*shim*c.a;}
 vec3 col=c.rgb+vec3(s);float al=max(c.a,a*glow*.9);gl_FragColor=vec4((col*c.a+gc*(1.-c.a)),al*inP);}`;
function sh(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s}
function mk(fs){const p=gl.createProgram();gl.attachShader(p,sh(gl.VERTEX_SHADER,VS));gl.attachShader(p,sh(gl.FRAGMENT_SHADER,fs));gl.bindAttribLocation(p,0,'p');gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(p));return p}
function init(){if(ok!==null)return ok;try{cv=document.createElement('canvas');gl=cv.getContext('webgl',{premultipliedAlpha:false,preserveDrawingBuffer:true,alpha:true});if(!gl)throw new Error('no webgl');
 prog=mk(FS);lprog=mk(LFS);buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
 const mt=()=>{const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);return t};tex=mt();tex2=mt();ok=true}catch(e){console.warn('[V7GL] disabled',e);ok=false}return ok}
function draw(p,src,t0){gl.useProgram(p);gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,2,gl.FLOAT,false,0,0);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,t0);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,src);gl.uniform1i(gl.getUniformLocation(p,'T'),0);gl.uniform2f(gl.getUniformLocation(p,'R'),cv.width,cv.height)}
const u=(p,n)=>gl.getUniformLocation(p,n);
function keyed(){try{if(window.V7CH&&V7CH.keyOut&&V7CH.keyOut())return true;if(window.V7FX&&V7FX.SET.key&&V7FX.program())return true;const m=(D.P()&&D.P().cine&&D.P().cine.out)||'full';return m!=='full'&&!(window.V7FX&&V7FX.program())}catch(e){return false}}
const D=window.DM5;
const V7GL=window.V7GL={SET,save,
 kick(type,o){const k=o.k||1;if(type==='shock'){shocks.push({x:o.x??.5,y:o.y??.5,t0:performance.now()/1000,k});if(shocks.length>4)shocks.shift()}else if(K[type]!=null)K[type]=Math.max(K[type],k)},
 available(){return init()},
 post(ctx){if(!SET.on||!init())return;const src=ctx.canvas;const busy=shocks.length||K.rgb>.01||K.glitch>.01||K.bloom>.01;const cont=SET.bloom>0||SET.grain>0||SET.vignette>0||SET.ca>0||SET.warp>0||SET.lift||SET.gamma!==1||SET.gain!==1||SET.warm||SET.sat!==1||SET.scan>0;
  if(!busy&&!cont)return;if(keyed())return;/* never touch the key colour */
  const fxOnly=!(window.V7FX&&V7FX.program());if(fxOnly&&!busy&&!SET.always)return;/* on v5 scenes only while an FX kick is alive, v5 has its own look */
  if(cv.width!==src.width||cv.height!==src.height){cv.width=src.width;cv.height=src.height}gl.viewport(0,0,cv.width,cv.height);const t=performance.now()/1000;
  draw(prog,src,tex);gl.uniform1f(u(prog,'t'),t);gl.uniform1f(u(prog,'rgb'),K.rgb+SET.ca);gl.uniform1f(u(prog,'glitch'),K.glitch);gl.uniform1f(u(prog,'bloom'),(fxOnly?0:SET.bloom)+K.bloom*.6);gl.uniform1f(u(prog,'grain'),fxOnly?0:SET.grain);gl.uniform1f(u(prog,'vig'),fxOnly?0:SET.vignette);gl.uniform1f(u(prog,'warp'),SET.warp);
  gl.uniform1f(u(prog,'lift'),fxOnly?0:SET.lift);gl.uniform1f(u(prog,'gam'),fxOnly?1:SET.gamma);gl.uniform1f(u(prog,'gain'),fxOnly?1:SET.gain);gl.uniform1f(u(prog,'warm'),fxOnly?0:SET.warm);gl.uniform1f(u(prog,'sat'),fxOnly?1:SET.sat);gl.uniform1f(u(prog,'scan'),SET.scan);
  const arr=new Float32Array(16);for(let i=shocks.length-1;i>=0;i--){const a=t-shocks[i].t0;if(a>1.2)shocks.splice(i,1)}shocks.forEach((s,i)=>{const a=t-s.t0;arr.set([s.x,s.y,a*.9,s.k*(1-a/1.2)],i*4)});gl.uniform4fv(u(prog,'S'),arr);
  gl.drawArrays(gl.TRIANGLE_STRIP,0,4);for(const k in K)K[k]*=.9;
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';ctx.drawImage(cv,0,0);ctx.restore()},
 /* returns a canvas with the processed layer (transparent) or null if WebGL is unavailable */
 layer(src,o){if(!init())return null;const L=this._l||(this._l=document.createElement('canvas'));if(L.width!==src.width||L.height!==src.height){L.width=src.width;L.height=src.height}
  if(cv.width!==src.width||cv.height!==src.height){cv.width=src.width;cv.height=src.height}gl.viewport(0,0,cv.width,cv.height);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);
  draw(lprog,src,tex2);gl.uniform1f(u(lprog,'t'),performance.now()/1000);gl.uniform1f(u(lprog,'glow'),o.glow||0);gl.uniform1f(u(lprog,'shim'),o.shim||0);gl.uniform1f(u(lprog,'wave'),o.wave||0);gl.uniform1f(u(lprog,'rgb'),o.rgb||0);gl.uniform1f(u(lprog,'inP'),o.inP==null?1:o.inP);const gc=o.gcol||[1,.8,.2];gl.uniform3f(u(lprog,'gcol'),gc[0],gc[1],gc[2]);
  gl.drawArrays(gl.TRIANGLE_STRIP,0,4);const c=L.getContext('2d');c.clearRect(0,0,L.width,L.height);c.drawImage(cv,0,0);return L}};
})();
