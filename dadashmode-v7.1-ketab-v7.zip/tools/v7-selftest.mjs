/* node tools/v7-selftest.mjs · runs the §9.7 acceptance numbers of Director Book V7 against the rules engine */
await import('../js/v7-rules.js');const R=globalThis.V7R;let pass=0,fail=0;
const eq=(name,got,exp)=>{const g=JSON.stringify(got),e=JSON.stringify(exp);if(g===e){pass++;console.log('✔',name)}else{fail++;console.log('✘',name,'\n   got',g,'\n   exp',e)}};
// R3
eq('R3 31.4 vs 46.8 → M +15',R.r3Score({E:{T:46.8,status:'final'},M:{T:31.4,status:'final'}}).awards,{M:15});
eq('R3 diff 0.6 → both +5',R.r3Score({E:{T:30.6,status:'final'},M:{T:30,status:'final'}}).awards,{E:5,M:5});
eq('R3 only one 34.6 → +20',R.r3Score({E:{T:34.6,status:'final'},M:{T:null,status:'dnf'}}).awards,{E:20});
eq('R3 diff 2.2 → floor +3',R.r3Score({E:{T:30,status:'final'},M:{T:32.2,status:'final'}}).awards,{E:3});
eq('R3 safety → both +5',R.r3Score({E:{},M:{}},{safety:true}).awards,{E:5,M:5});
eq('R3 DQ, other finished → +10',R.r3Score({E:{status:'dq'},M:{T:40,status:'final'}}).awards,{M:10});
eq('R3 DQ, other not finished → +5',R.r3Score({E:{status:'dq'},M:{status:'dnf'}}).awards,{M:5});
eq('R3 nobody → needs pick',R.r3Score({E:{status:'dnf'},M:{status:'dnf'}}).need,'pick');
eq('R3 penalty +3 counts',R.r3Score({E:{T:30,status:'final',pen:3},M:{T:40,status:'final'}}).awards,{E:7});
// R2 farther = more
eq('R2 values 2m/3m/4m',[R.r2Value('L1'),R.r2Value('L2'),R.r2Value('L3')],[5,10,20]);
eq('R2 trailing throws first (book §3.4)',R.r2Order({E:'L2',M:'L3'},{E:45,M:55}),['E','M']);eq('R2 equal banks → director decides',R.r2Order({E:'L2',M:'L3'},{E:45,M:45}),null);
// R4
eq('R4 first +15',R.r4Score({first:'M'}),{M:15});
eq('R4 challenge win 10/5',R.r4Score({first:'M',challenge:{by:'E',result:'win'}}),{M:5,E:10});
eq('R4 challenge lose −5',R.r4Score({first:'M',challenge:{by:'E',result:'lose'}}),{M:15,E:-5});
eq('R4 unclear 0',R.r4Score({first:'M',challenge:{by:'E',result:'unclear'}}),{M:15});
// story fixture 45|45 → 65|95 → 55|80 → 85|70
let b={E:45,M:45};const add=a=>{for(const k in a)b[k]+=a[k]};
add(R.r1Score({winner:'M'}));add({E:R.r2Value('L2'),M:R.r2Value('L3')});add(R.r3Score({E:{T:46.8,status:'final'},M:{T:31.4,status:'final'}}).awards);
add(R.r4Score({first:'M',challenge:{by:'E',result:'win'}}));eq('Story after R4 = 65|95',b,{E:65,M:95});
eq('Reveal gap 30 → no cap',R.gapCap(b).apply,false);eq('Gap 31 → trailing lifted to leader−30',R.gapCap({E:60,M:91}).newTrail,61);
const res=R.shopResolve({E:['HINT'],M:['SPICY']},b);add({E:-res.costs.E,M:-res.costs.M});eq('Shop with tax → 55|80',b,{E:55,M:80});
eq('SPICY → E active',res.effects.E.spicy,true);
const ro=R.riskOptions('E',b);eq('All-in legal for E (55−30=25≥20)',ro[30].ok,true);eq('All-in not for leader',R.riskOptions('M',b)[30].ok,false);
add({E:30,M:-10});eq('Risk → 85|70',b,{E:85,M:70});
// shop rules
const av=R.shopAvail('E',['GLOVES'],{E:60,M:40});eq('2nd red disabled',av.SPICY.ok,false);
eq('3rd card disabled',R.shopAvail('E',['HINT','SHIELD'],{E:90,M:40}).MIRROR.ok,false);
eq('Card below floor 20 grey',R.shopAvail('E',[],{E:28,M:40}).HINT.ok,false);eq('Exactly 20 legal',R.shopAvail('E',[],{E:30,M:40}).HINT.ok,true);
eq('Red vs shield → blocked',R.shopResolve({E:['GLOVES'],M:['SHIELD']},{E:50,M:50}).effects.M.gloves,false);
const mr=R.shopResolve({E:['GLOVES'],M:['MIRROR']},{E:50,M:50});eq('Red vs mirror → bounced to buyer',[mr.effects.E.gloves,mr.effects.M.gloves],[true,false]);
const mm=R.shopResolve({E:['GLOVES','MIRROR'],M:['MIRROR']},{E:50,M:50});eq('Mirror vs mirror → once only',[mm.effects.E.gloves,mm.effects.M.gloves],[true,false]);
const ms=R.shopResolve({E:['SPICY'],M:['MIRROR','SHIELD']},{E:50,M:50});eq('Mirror first, shield burns',[ms.effects.E.spicy,ms.labels.some(l=>l.card==='SHIELD'&&l.res==='BURNED')],[true,true]);
eq('No card changes bank beyond its price',R.shopResolve({E:['GLOVES'],M:[]},{E:50,M:50}).costs,{E:15,M:0});
// memory + riddle + code
const p=R.memPattern(12345);const g=p.reduce((a,c)=>a+c,0);eq('Memory pattern 8 bits, 3..5 gold',[p.length,g>=3&&g<=5],[8,true]);
eq('Memory CHECK n of 8',R.memCheck([1,0,1,1,0,0,1,0],[1,0,1,1,0,0,0,1]),6);
eq('Riddle bucket 2 for code 472',R.riddlePick(2).answer,2);eq('Spicy keeps answer',R.riddleText(R.riddlePick(2),{spicy:true})===R.riddlePick(2).spicy,true);
eq('Drawing judge first noun',R.judgeWord('دوچرخه','فکر کنم دوچرخه باشه').ok,true);eq('Drawing judge wrong',R.judgeWord('دوچرخه','عینک').ok,false);
const s1=await R.sealHash('472','x9'),s2=await R.sealHash('472','x9');eq('Seal hash stable 6 hex',[s1===s2,/^[0-9A-F]{6}$/.test(s1)],[true,true]);
eq('Final: open beats timeout',R.finalRank({E:{opened:true,left:1},M:{opened:false,codes:3}}).winner,'E');
eq('Final: more time wins',R.finalRank({E:{opened:true,left:5.3},M:{opened:true,left:12.4}}).winner,'M');
eq('Final: tie 0.1 → sudden death',R.finalRank({E:{opened:true,left:5.3},M:{opened:true,left:5.3}}).why,'SUDDEN_DEATH_TIME');
console.log(`\n${pass} passed, ${fail} failed`);process.exit(fail?1:0);
